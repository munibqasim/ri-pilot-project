#!/usr/bin/env python
# coding: utf-8

# ### Key words List

# In[1]:


# Comprehensive RI Keyword Taxonomy
RI_KEYWORDS = {
    
    # CORE RI TERMS (Cross-cutting)
    "core_resilience": [
        "resilient", "resilience",
        "climate-proof", "climate-proofing", "climateproof",
        "disaster-resistant", "disaster risk",
        "adaptive", "adaptation", "adaptability",
        "robust", "robustness",
        "redundancy", "redundant",
        "flexible", "flexibility",
        "withstand",
        "climate change",
        "extreme event", "extreme weather",
        "hazard mitigation",
        "risk-informed",
        "future-proof"
    ],
    
    # HAZARD KEYWORDS
    "hazards": [
        "flood", "flooding", "floodplain", "inundation",
        "seismic", "earthquake", "tremor",
        "cyclone", "hurricane", "typhoon", "storm surge",
        "drought", "water scarcity",
        "heat", "heatwave", "temperature extreme",
        "landslide", "erosion", "slope failure",
        "wind", "windstorm", "gale",
        "fire", "wildfire",
        "tsunami",
        "coastal erosion", "sea level rise",
        "precipitation", "rainfall", "heavy rain",
        "lightning",
        "avalanche"
    ],
    
    # RESILIENCE ACTIVITIES (8 Pillars)
    "activities": [
        "asset management",
        "preventive maintenance", "predictive maintenance",
        "condition monitoring", "structural health monitoring",
        "contingency plan", "emergency response", "business continuity",
        "early warning system",
        "disaster preparedness",
        "system planning", "systems approach",
        "risk assessment", "vulnerability assessment", "hazard assessment",
        "climate screening", "climate risk",
        "institutional capacity",
        "stakeholder engagement",
        "backup system",
        "design standards", "engineering standards"
    ],
    
    # ENERGY SECTOR
    "energy": [
        # Infrastructure
        "substation", "transmission line", "distribution line", "power grid",
        "hydropower", "dam", "reservoir", "spillway",
        "generator", "turbine", "transformer",
        
        # Resilience Features
        "elevated substation", "raised substation",
        "flood-proof", "floodproofing",
        "mobile substation", "portable substation",
        "backup power", "emergency power", "auxiliary power",
        "battery storage", "energy storage", "BESS",
        "microgrid", "mini-grid", "off-grid",
        "N-1 redundancy",
        "grid stability", "system reliability",
        "corrosion-resistant",
        "wind-resistant tower", "reinforced tower",
        "seismic design",
        "insulated cable", "weatherproof cable",
        "underground cabling",
        "dam safety", "dam monitoring",
        "hydrology study", "hydrological analysis"
    ],
    
    # TRANSPORT SECTOR - ROADS
    "transport_roads": [
        "elevated roadbed", "raised embankment",
        "climate-resilient pavement", "heat-resistant pavement",
        "drainage system", "culvert", "stormwater",
        "flood-resistant",
        "erosion control", "slope stabilization", "bioengineering",
        "all-weather road", "all-season connectivity",
        "reinforced pavement",
        "retaining wall",
        "bridge elevation", "bridge clearance",
        "road asset management",
        "pavement condition",
        "climate risk-informed prioritization"
    ],
    
    # TRANSPORT SECTOR - RAILWAYS
    "transport_rail": [
        "track buckling", "thermal stress",
        "heat-resistant rail", "rail expansion joint",
        "signaling system resilience",
        "climate-resilient signaling",
        "fire safety", "fire-retardant",
        "insulated wiring", "weatherproof circuit",
        "railway drainage",
        "early warning system",
        "safety management system",
        "contingency plan"
    ],
    
    # TRANSPORT SECTOR - PORTS & MARITIME
    "transport_ports": [
        "quay wall", "underwater structure",
        "wave protection", "breakwater",
        "sea level rise",
        "coastal defense", "shoreline protection",
        "storm surge protection",
        "fendering system", "anchoring system",
        "floating pontoon", "modular floating",
        "dredging",
        "port drainage",
        "weather forecast", "navigation aids",
        "search and rescue", "SAR"
    ],
    
    # TRANSPORT SECTOR - AIRPORTS
    "transport_airports": [
        "runway drainage", "apron drainage",
        "pavement resilience",
        "firefighting system",
        "airfield resilience",
        "emergency landing",
        "rescue coordination",
        "air traffic control", "ATCT"
    ],
    
    # TRANSPORT SECTOR - URBAN MOBILITY
    "transport_urban": [
        "BRT", "bus rapid transit",
        "climate resilience standards",
        "flood-resistant infrastructure",
        "elevated station",
        "integrated drainage",
        "heat mitigation", "shade trees", "green infrastructure",
        "pedestrian walkway", "cycle lane",
        "multimodal hub"
    ],
    
    # WATER SECTOR
    "water": [
        "water treatment plant",
        "pipeline protection",
        "pump station",
        "reservoir capacity",
        "flood-resistant facility",
        "leak detection",
        "pressure management",
        "water supply continuity",
        "emergency water supply",
        "drought management",
        "wastewater treatment",
        "sewage system",
        "overflow management"
    ],
    
    # DIGITAL SECTOR
    "digital": [
        "data center resilience",
        "backup facility",
        "redundant connectivity", "failover system",
        "fiber optic protection",
        "backup power", "UPS", "generator",
        "disaster recovery plan",
        "network redundancy",
        "emergency communication"
    ],
    
    # CROSS-SECTORAL
    "cross_sectoral": [
        "multi-sectoral", "cross-sectoral",
        "system of systems",
        "cascading failure", "cascading risk",
        "interdependency", "interconnection",
        "integrated planning"
    ],
    
    # INSTITUTIONAL & GOVERNANCE
    "institutional": [
        "institutional capacity building",
        "regulatory framework", "policy reform",
        "climate mainstreaming",
        "technical guideline", "design manual",
        "coordination mechanism",
        "governance structure",
        "environmental and social management",
        "gender mainstreaming", "social inclusion",
        "community engagement", "participatory planning"
    ],
    
    # FINANCING INSTRUMENTS
    "financing": [
        "Cat DDO", "catastrophe deferred drawdown",
        "PforR", "program-for-results",
        "CERC", "contingent emergency response",
        "climate finance", "climate co-benefit",
        "results-based financing", "RBF",
        "availability payment",
        "PPP", "public-private partnership",
        "performance-based contract"
    ]
}

# Flatten into single list for searching
ALL_KEYWORDS = []
for category, keywords in RI_KEYWORDS.items():
    ALL_KEYWORDS.extend(keywords)

# Remove duplicates while preserving order
ALL_KEYWORDS = list(dict.fromkeys(ALL_KEYWORDS))

print(f"Total keywords: {len(ALL_KEYWORDS)}")

# In[19]:


import re
import spacy
from typing import List, Dict, Tuple
import PyPDF2
from dataclasses import dataclass

# Load spaCy model for lemmatization
nlp = spacy.load("en_core_web_sm")

@dataclass
class KeywordMatch:
    """Store information about a keyword match"""
    chunk_id: str
    text: str
    matched_keywords: List[str]
    char_start: int
    char_end: int
    source: str = "keyword_search"
    section_name: str = ""
    page_number: int = 0


class KeywordSearcher:
    """Handles keyword-based search with lemmatization"""
    
    def __init__(self, keywords: List[str]):
        self.keywords = keywords
        self.lemmatizer = WordNetLemmatizer()
        self.lemmatized_keywords = self._create_keyword_patterns()
    
    def _lemmatize_word(self, word: str) -> str:
        """Lemmatize a single word"""
        word = word.lower().strip()
        # Try as noun, verb, adjective
        lemmas = {
            self.lemmatizer.lemmatize(word, pos='n'),
            self.lemmatizer.lemmatize(word, pos='v'),
            self.lemmatizer.lemmatize(word, pos='a'),
        }
        # Return the shortest lemma (usually most canonical)
        return min(lemmas, key=len)
    
    def _create_keyword_patterns(self) -> Dict[str, List[str]]:
        """Create lemmatized patterns for each keyword"""
        patterns = {}
        
        for keyword in self.keywords:
            # Handle multi-word phrases
            words = keyword.lower().split()
            
            if len(words) == 1:
                # Single word - create lemma
                lemma = self._lemmatize_word(words[0])
                if lemma not in patterns:
                    patterns[lemma] = []
                patterns[lemma].append(keyword)
            else:
                # Multi-word phrase - lemmatize each word
                lemmas = [self._lemmatize_word(w) for w in words]
                pattern_key = " ".join(lemmas)
                if pattern_key not in patterns:
                    patterns[pattern_key] = []
                patterns[pattern_key].append(keyword)
        
        return patterns
    
    def _find_keyword_positions(self, text: str) -> List[Tuple[int, int, str]]:
        """Find all positions where keywords appear (with lemmatization)
        Returns: List of (start_pos, end_pos, single_keyword)
        """
        text_lower = text.lower()
        matches = []
        
        for pattern, original_keywords in self.lemmatized_keywords.items():
            pattern_words = pattern.split()
            
            # Use just the FIRST original keyword (they're lemma equivalents anyway)
            representative_keyword = original_keywords[0]
            
            if len(pattern_words) == 1:
                # Single word search with lemmatization
                words = word_tokenize(text_lower)
                
                for i, word in enumerate(words):
                    word_lemma = self._lemmatize_word(word)
                    if word_lemma == pattern:
                        # Find actual position in original text
                        start = text_lower.find(word, sum(len(w) + 1 for w in words[:i]))
                        if start != -1:
                            end = start + len(word)
                            matches.append((start, end, representative_keyword))
            else:
                # Multi-word phrase
                regex_pattern = r'\b' + r'\s+'.join(
                    [re.escape(w) for w in pattern_words]
                ) + r'\b'
                
                for match in re.finditer(regex_pattern, text_lower):
                    matches.append((match.start(), match.end(), representative_keyword))
        
        return matches
    
    def _extract_context(self, text: str, match_start: int, match_end: int) -> Tuple[str, int, int]:
        """Extract context around a match (paragraph or sentence-based)"""
        
        # First try: Extract by paragraph
        paragraphs = text.split('\n\n')
        current_pos = 0
        
        for para in paragraphs:
            para_end = current_pos + len(para)
            
            if current_pos <= match_start <= para_end:
                para_clean = para.strip()
                
                # Check character limits
                if 200 <= len(para_clean) <= 1000:
                    return para_clean, current_pos, para_end
                elif len(para_clean) < 200:
                    # Too short - expand
                    return self._expand_context(text, current_pos, para_end)
                else:
                    # Too long - use sentence-based extraction
                    return self._extract_by_sentences(text, match_start)
            
            current_pos = para_end + 2  # +2 for \n\n
        
        # Fallback: sentence-based extraction
        return self._extract_by_sentences(text, match_start)
    
    def _extract_by_sentences(self, text: str, match_pos: int, 
                              before: int = 3, after: int = 3) -> Tuple[str, int, int]:
        """Extract context using sentence boundaries"""
        sentences = sent_tokenize(text)
        
        # Find sentence containing match
        current_pos = 0
        target_idx = None
        
        for idx, sent in enumerate(sentences):
            sent_end = current_pos + len(sent)
            if current_pos <= match_pos <= sent_end:
                target_idx = idx
                break
            current_pos = sent_end + 1
        
        if target_idx is None:
            # Fallback: fixed window
            start = max(0, match_pos - 300)
            end = min(len(text), match_pos + 300)
            return text[start:end], start, end
        
        # Get surrounding sentences
        start_idx = max(0, target_idx - before)
        end_idx = min(len(sentences), target_idx + after + 1)
        
        context_sents = sentences[start_idx:end_idx]
        context_text = " ".join(context_sents)
        
        # Calculate character positions (approximate)
        char_start = sum(len(s) + 1 for s in sentences[:start_idx])
        char_end = char_start + len(context_text)
        
        # Ensure within character limits
        if len(context_text) < 200:
            return self._expand_context(text, char_start, char_end)
        elif len(context_text) > 1000:
            match_offset = match_pos - char_start
            half = 500
            truncated = context_text[max(0, match_offset - half):match_offset + half]
            return truncated, char_start, char_start + len(truncated)
        
        return context_text, char_start, char_end
    
    def _expand_context(self, text: str, start: int, end: int) -> Tuple[str, int, int]:
        """Expand context to meet minimum 200 character requirement"""
        while (end - start) < 200 and (start > 0 or end < len(text)):
            if start > 0:
                start = max(0, start - 100)
            if end < len(text):
                end = min(len(text), end + 100)
        
        expanded_text = text[start:end].strip()
        return expanded_text, start, start + len(expanded_text)
    
    def search(self, text: str, section_name: str = "", 
               page_number: int = 0) -> List[KeywordMatch]:
        """Search for all keyword matches in text"""
        
        # Find all keyword positions
        keyword_positions = self._find_keyword_positions(text)
        
        if not keyword_positions:
            return []
        
        # Group keywords by position
        position_keywords = {}
        
        for start, end, keyword in keyword_positions:
            key = (start, end)
            if key not in position_keywords:
                position_keywords[key] = []
            position_keywords[key].append(keyword)
        
        # Extract context for each unique position
        matches = []
        seen_positions = set()
        
        for (start, end), keywords in position_keywords.items():
            # Deduplicate keywords at this position
            unique_keywords = list(set(keywords))
            
            # Skip if overlapping
            if start in seen_positions:
                continue
            seen_positions.add(start)
            
            # Extract context
            context_text, context_start, context_end = self._extract_context(text, start, end)
            
            # Create match object
            match = KeywordMatch(
                chunk_id=f"keyword_{len(matches):04d}",
                text=context_text,
                matched_keywords=unique_keywords,
                char_start=context_start,
                char_end=context_end,
                section_name=section_name,
                page_number=page_number
            )
            
            matches.append(match)
        
        # Merge overlapping matches
        merged = self._merge_overlapping(matches)
        
        return merged
    
    def _merge_overlapping(self, matches: List[KeywordMatch]) -> List[KeywordMatch]:
        """Merge matches with overlapping text positions"""
        if not matches:
            return []
        
        # Sort by start position
        sorted_matches = sorted(matches, key=lambda x: x.char_start)
        merged = [sorted_matches[0]]
        
        for current in sorted_matches[1:]:
            last = merged[-1]
            
            # Calculate overlap
            overlap_start = max(last.char_start, current.char_start)
            overlap_end = min(last.char_end, current.char_end)
            
            if overlap_start < overlap_end:
                overlap_ratio = (overlap_end - overlap_start) / (last.char_end - last.char_start)
                
                if overlap_ratio > 0.5:
                    # Merge
                    all_keywords = last.matched_keywords + current.matched_keywords
                    last.matched_keywords = list(set(all_keywords))
                    last.char_end = max(last.char_end, current.char_end)
                    if len(current.text) > len(last.text):
                        last.text = current.text
                    continue
            
            merged.append(current)
        
        return merged


# USAGE EXAMPLE
if __name__ == "__main__":
    # Initialize searcher
    searcher = KeywordSearcher(ALL_KEYWORDS)
    
    # Example: Search in a PAD document
    sample_text = """
    Component 2: Transmission System Upgrade
    
    The project will rehabilitate and upgrade 15 substations to enhance their 
    resilience to flooding and seismic events. Key interventions include:
    
    (i) Elevating critical equipment above the 100-year flood level;
    (ii) Installing seismic isolation systems for transformers and switchgear;
    (iii) Deploying mobile substations for rapid response and recovery to climate events;
    (iv) Establishing a real-time condition monitoring system to detect equipment 
    stress during extreme weather conditions.
    
    The transmission lines will be upgraded with corrosion-resistant materials and 
    reinforced tower foundations to withstand strong winds and heavy precipitation.
    """
    
    # Search for keywords
    matches = searcher.search(sample_text, section_name="Component 2", page_number=15)
    
    # Display results
    print(f"\nFound {len(matches)} keyword matches:\n")
    for match in matches:
        print(f"Chunk ID: {match.chunk_id}")
        print(f"Keywords: {', '.join(match.matched_keywords)}")
        print(f"Text: {match.text[:200]}...")
        print(f"Position: {match.char_start}-{match.char_end}\n")

# In[23]:


import nltk
from typing import List, Dict
import json

# Download required NLTK data (run once)
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')
    nltk.download('omw-1.4')
    nltk.download('punkt')

# Your PAD file paths
PAD_FILES = [
    "/Users/munibqasimzia/Desktop/Munib Qasim Zia/World Bank/2024 FY/Harsh Team/IPF Components Extraction/IPF_PAD/IPF-2010-18/pad_P150816_2017-04-14_D27370130.txt"
]

def load_pad_text(file_path: str) -> str:
    """Load text from PAD file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def process_pad(file_path: str, searcher: KeywordSearcher) -> Dict:
    """Process a single PAD document"""
    print(f"\n{'='*80}")
    print(f"Processing: {file_path.split('/')[-1]}")
    print(f"{'='*80}")
    
    # Load text
    text = load_pad_text(file_path)
    print(f"Document length: {len(text):,} characters")
    
    # Search for keywords
    matches = searcher.search(text)
    print(f"✓ Found {len(matches)} keyword matches")
    
    # Count keyword occurrences CORRECTLY
    keyword_counts = {}
    for match in matches:
        for kw in match.matched_keywords:
            keyword_counts[kw] = keyword_counts.get(kw, 0) + 1  # +1 per match, not cumulative!
    
    unique_keywords = set(keyword_counts.keys())
    print(f"✓ Unique keywords matched: {len(unique_keywords)}")
    print(f"\nTop matched keywords:")
    
    # Show top 10
    top_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    for kw, count in top_keywords:
        print(f"  - {kw}: {count} matches")  # "matches" not "occurrences"
    
    # Return results
    return {
        'file_path': file_path,
        'file_name': file_path.split('/')[-1],
        'project_id': file_path.split('_')[1],
        'total_matches': len(matches),
        'unique_keywords': len(unique_keywords),
        'matches': matches,
        'keyword_counts': keyword_counts
    }

def display_sample_matches(matches: List[KeywordMatch], num_samples: int = 3):
    """Display sample matches for review"""
    print(f"\n--- Sample Matches (showing {min(num_samples, len(matches))} of {len(matches)}) ---\n")
    
    for i, match in enumerate(matches[:num_samples]):
        print(f"Match #{i+1}:")
        print(f"  Chunk ID: {match.chunk_id}")
        print(f"  Keywords: {', '.join(match.matched_keywords[:5])}")  # Show first 5 keywords
        print(f"  Position: {match.char_start}-{match.char_end}")
        print(f"  Text preview:")
        # Show first 300 chars
        preview = match.text[:300] + "..." if len(match.text) > 300 else match.text
        print(f"    {preview}")
        print()

def save_results(results: List[Dict], output_file: str = "keyword_search_results.json"):
    """Save results to JSON file"""
    # Convert KeywordMatch objects to dicts for JSON serialization
    json_results = []
    
    for result in results:
        matches_dicts = []
        for match in result['matches']:
            matches_dicts.append({
                'chunk_id': match.chunk_id,
                'text': match.text,
                'matched_keywords': match.matched_keywords,
                'char_start': match.char_start,
                'char_end': match.char_end,
                'source': match.source
            })
        
        json_results.append({
            'file_name': result['file_name'],
            'project_id': result['project_id'],
            'total_matches': result['total_matches'],
            'unique_keywords': result['unique_keywords'],
            'keyword_counts': result['keyword_counts'],
            'matches': matches_dicts
        })
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(json_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Results saved to: {output_file}")

# MAIN EXECUTION
if __name__ == "__main__":
    print("="*80)
    print("KEYWORD SEARCH - RESILIENT INFRASTRUCTURE")
    print("="*80)
    
    # Initialize searcher
    print("\nInitializing keyword searcher...")
    searcher = KeywordSearcher(ALL_KEYWORDS)
    print(f"✓ Loaded {len(ALL_KEYWORDS)} keywords")
    
    # Process each PAD
    all_results = []
    
    for pad_file in PAD_FILES:
        try:
            result = process_pad(pad_file, searcher)
            all_results.append(result)
            
            # Display sample matches
            display_sample_matches(result['matches'], num_samples=3)
            
        except Exception as e:
            print(f"❌ Error processing {pad_file}: {str(e)}")
            import traceback
            traceback.print_exc()
    
    # Summary across all PADs
    print("\n" + "="*80)
    print("SUMMARY ACROSS ALL PADS")
    print("="*80)
    
    total_matches = sum(r['total_matches'] for r in all_results)
    print(f"\nTotal PADs processed: {len(all_results)}")
    print(f"Total keyword matches: {total_matches}")
    
    for result in all_results:
        print(f"\n{result['file_name']}:")
        print(f"  - Matches: {result['total_matches']}")
        print(f"  - Unique keywords: {result['unique_keywords']}")
    
    # Save results
    save_results(all_results)
    
    print("\n" + "="*80)
    print("KEYWORD SEARCH COMPLETE")
    print("="*80)

# ### Semantic Search 

# In[26]:


# Semantic search queries - highly specific to each sector
SEMANTIC_QUERIES = {
    "energy": [
        "Infrastructure designed to withstand floods, earthquakes, storms, and extreme weather including elevated substations, seismic protection, flood-resistant power plants, and climate-resilient transmission lines",
        
        "Backup power systems, mobile substations, redundant electricity supply, emergency generators, and rapid recovery mechanisms for power grid resilience during disasters and climate events",
        
        "Asset management systems for monitoring electricity infrastructure condition, preventive maintenance of transformers and substations, and lifecycle management of power generation and distribution networks"
    ],
    
    "transport_roads": [
        "Climate-resilient road design including elevated roadbeds, improved drainage systems, flood-resistant pavements, erosion control, slope stabilization, and all-weather road construction standards",
        
        "Road asset management systems with climate risk considerations, pavement condition monitoring, performance-based maintenance contracts, and infrastructure vulnerability assessments for extreme weather"
    ],
    
    "transport_rail": [
        "Railway infrastructure resilience including track buckling prevention, heat-resistant rails, climate-resilient signaling systems, fire safety measures, and early warning systems for extreme weather events affecting rail operations"
    ],
    
    "transport_ports_airports": [
        "Port and airport infrastructure designed to withstand sea level rise, storm surge, flooding, and extreme winds including reinforced quay walls, improved drainage systems, elevated runways, and coastal protection measures",
        
        "Maritime and aviation safety systems including weather monitoring, emergency response capabilities, rescue coordination, contingency planning for climate disasters, and business continuity for transport operations"
    ],
    
    "water": [
        "Water infrastructure resilience including flood-resistant treatment plants, drought management systems, emergency water supply mechanisms, pipeline protection, and climate-adaptive water resource management"
    ],
    
    "cross_cutting": [
        "Institutional capacity building for resilient infrastructure including policy frameworks, technical guidelines, coordination mechanisms, climate risk screening, and stakeholder engagement for disaster preparedness",
        
        "Contingency planning, business continuity, early warning systems, emergency response protocols, and disaster risk management integrated into infrastructure planning and operations",
        
        "Climate vulnerability assessments, hazard mapping, risk-informed infrastructure planning, and performance indicators measuring resilience outcomes and climate adaptation benefits"
    ]
}

# Flatten for iteration
ALL_SEMANTIC_QUERIES = []
for sector, queries in SEMANTIC_QUERIES.items():
    for query in queries:
        ALL_SEMANTIC_QUERIES.append({
            'sector': sector,
            'query': query
        })

print(f"Total semantic queries: {len(ALL_SEMANTIC_QUERIES)}")
# Should be 13 queries total

# In[38]:


from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List, Dict, Tuple
from dataclasses import dataclass
import torch

@dataclass
class SemanticMatch:
    """Store information about a semantic search match"""
    chunk_id: str
    text: str
    similarity_score: float
    matched_query: str
    sector: str
    char_start: int
    char_end: int
    source: str = "semantic_search"


class SemanticSearcher:
    """Handles semantic search using sentence embeddings"""
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize semantic searcher
        
        Args:
            model_name: Sentence transformer model
                - "all-MiniLM-L6-v2" - Fast, good quality (default)
                - "all-mpnet-base-v2" - Better quality, slower
        """
        print(f"Loading embedding model: {model_name}...")
        self.model = SentenceTransformer(model_name)
        print("✓ Model loaded")
    
    def _create_chunks(self, text: str, chunk_size: int = 500, 
                       overlap: int = 100) -> List[Tuple[str, int, int]]:
        """
        Create overlapping text chunks
        
        Args:
            text: Full document text
            chunk_size: Target chunk size in characters
            overlap: Overlap between chunks in characters
        
        Returns:
            List of (chunk_text, start_pos, end_pos)
        """
        chunks = []
        
        # Split by paragraphs first
        paragraphs = text.split('\n\n')
        
        current_chunk = ""
        chunk_start = 0
        current_pos = 0
        
        for para in paragraphs:
            para = para.strip()
            if not para:
                current_pos += 2  # \n\n
                continue
            
            # If adding this paragraph exceeds chunk_size, save current chunk
            if len(current_chunk) + len(para) > chunk_size and current_chunk:
                chunks.append((
                    current_chunk.strip(),
                    chunk_start,
                    current_pos
                ))
                
                # Start new chunk with overlap
                overlap_text = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
                current_chunk = overlap_text + " " + para
                chunk_start = current_pos - len(overlap_text)
            else:
                # Add to current chunk
                if current_chunk:
                    current_chunk += " " + para
                else:
                    current_chunk = para
                    chunk_start = current_pos
            
            current_pos += len(para) + 2  # +2 for \n\n
        
        # Add final chunk
        if current_chunk:
            chunks.append((
                current_chunk.strip(),
                chunk_start,
                current_pos
            ))
        
        return chunks
    
    def search(self, text: str, queries: List[Dict[str, str]], 
           top_k: int = 10) -> List[SemanticMatch]:
        """
        Search for semantically similar content
        
        Args:
            text: Document text to search
            queries: List of dicts with 'sector' and 'query' keys
            top_k: Number of top results per query (NO THRESHOLD)
        
        Returns:
            List of SemanticMatch objects
        """
        print(f"\nCreating text chunks...")
        chunks = self._create_chunks(text, chunk_size=500, overlap=100)
        print(f"✓ Created {len(chunks)} chunks")
        
        if not chunks:
            return []
        
        # Encode all chunks
        print("Encoding chunks...")
        chunk_texts = [c[0] for c in chunks]
        chunk_embeddings = self.model.encode(
            chunk_texts,
            convert_to_tensor=True,
            show_progress_bar=True
        )
        
        # Search with each query
        all_matches = []
        
        for query_info in queries:
            sector = query_info['sector']
            query = query_info['query']
            
            print(f"\nSearching with {sector} query...")
            
            # Encode query
            query_embedding = self.model.encode(
                query,
                convert_to_tensor=True
            )
            
            # Compute cosine similarities
            similarities = torch.nn.functional.cosine_similarity(
                query_embedding.unsqueeze(0),
                chunk_embeddings
            )
            
            # Diagnostic output
            max_sim = similarities.max().item()
            mean_sim = similarities.mean().item()
            print(f"  Max similarity: {max_sim:.3f}, Mean: {mean_sim:.3f}")
            
            # Get top-k results (NO THRESHOLD - just take top-k)
            top_indices = torch.argsort(similarities, descending=True)[:top_k]
            
            print(f"  Top-{top_k} scores: {[f'{similarities[i].item():.3f}' for i in top_indices[:5]]}")
            
            # Create matches for ALL top-k results
            for idx in top_indices:
                score = similarities[idx].item()
                chunk_text, start, end = chunks[idx]
                
                match = SemanticMatch(
                    chunk_id=f"semantic_{len(all_matches):04d}",
                    text=chunk_text,
                    similarity_score=score,
                    matched_query=query[:100] + "...",
                    sector=sector,
                    char_start=start,
                    char_end=end
                )
                
                all_matches.append(match)
            
            print(f"  Added {top_k} matches")
        
        # Remove duplicate chunks (same position, keep highest score)
        deduplicated = self._deduplicate_by_position(all_matches)
        
        print(f"\n✓ Total semantic matches (after dedup): {len(deduplicated)}")
        return deduplicated

    
    def _deduplicate_by_position(self, matches: List[SemanticMatch]) -> List[SemanticMatch]:
        """Remove duplicate matches at the same position, keeping highest score"""
        if not matches:
            return []
        
        # Group by position
        position_map = {}
        
        for match in matches:
            key = (match.char_start, match.char_end)
            
            if key not in position_map:
                position_map[key] = match
            else:
                # Keep the one with higher similarity score
                if match.similarity_score > position_map[key].similarity_score:
                    position_map[key] = match
        
        return list(position_map.values())


# USAGE
def process_pad_semantic_search(file_path: str, queries: List[Dict[str, str]], 
                                top_k: int = 10) -> Dict:
    """Process a PAD with semantic search"""
    
    print(f"\n{'='*80}")
    print(f"SEMANTIC SEARCH: {file_path.split('/')[-1]}")
    print(f"{'='*80}")
    
    # Load text
    with open(file_path, 'r', encoding='utf-8') as f:
        text = f.read()
    
    print(f"Document length: {len(text):,} characters")
    
    # Initialize searcher
    searcher = SemanticSearcher(model_name="all-MiniLM-L6-v2")
    
    # Search - REMOVE similarity_threshold parameter
    matches = searcher.search(text, queries, top_k=top_k)  # ← FIXED
    
    # Summary by sector
    sector_counts = {}
    for match in matches:
        sector_counts[match.sector] = sector_counts.get(match.sector, 0) + 1
    
    print(f"\n--- Matches by Sector ---")
    for sector, count in sorted(sector_counts.items()):
        print(f"  {sector}: {count} matches")
    
    return {
        'file_name': file_path.split('/')[-1],
        'project_id': file_path.split('_')[1],
        'total_matches': len(matches),
        'sector_breakdown': sector_counts,
        'matches': matches
    }


def save_semantic_results(results: List[Dict], output_file: str = "semantic_search_results.json"):
    """Save semantic search results to JSON"""
    
    json_results = []
    
    for result in results:
        matches_dicts = []
        for match in result['matches']:
            matches_dicts.append({
                'chunk_id': match.chunk_id,
                'text': match.text,
                'similarity_score': match.similarity_score,
                'matched_query': match.matched_query,
                'sector': match.sector,
                'char_start': match.char_start,
                'char_end': match.char_end,
                'source': match.source
            })
        
        json_results.append({
            'file_name': result['file_name'],
            'project_id': result['project_id'],
            'total_matches': result['total_matches'],
            'sector_breakdown': result['sector_breakdown'],
            'matches': matches_dicts
        })
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(json_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Semantic search results saved to: {output_file}")


# MAIN EXECUTION
if __name__ == "__main__":
    
    print("="*80)
    print("SEMANTIC SEARCH - RESILIENT INFRASTRUCTURE")
    print("="*80)
    
    # Your PAD files
    PAD_FILES = [
        "/Users/munibqasimzia/Desktop/Munib Qasim Zia/World Bank/2024 FY/Harsh Team/IPF Components Extraction/IPF_PAD/IPF 19 ons/pad_P162151_2020-05-07_D32037168.txt",
        "/Users/munibqasimzia/Desktop/Munib Qasim Zia/World Bank/2024 FY/Harsh Team/IPF Components Extraction/IPF_PAD/IPF-2010-18/pad_P150816_2017-04-14_D27370130.txt"
    ]
    
    # Process each PAD
    all_results = []
    
    for pad_file in PAD_FILES:
        try:
            result = process_pad_semantic_search(
                pad_file, 
                ALL_SEMANTIC_QUERIES, 
                top_k=10  # Just top-10, no threshold
            )
            all_results.append(result)
            
            # Display sample matches
            print(f"\n--- Sample Matches (top 3) ---")
            for i, match in enumerate(result['matches'][:3]):
                print(f"\nMatch #{i+1}:")
                print(f"  Sector: {match.sector}")
                print(f"  Similarity: {match.similarity_score:.3f}")
                print(f"  Query: {match.matched_query}")
                print(f"  Text: {match.text[:200]}...")
            
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
    
    # Summary
    print("\n" + "="*80)
    print("SEMANTIC SEARCH SUMMARY")
    print("="*80)
    
    total_matches = sum(r['total_matches'] for r in all_results)
    print(f"\nTotal semantic matches: {total_matches}")
    
    for result in all_results:
        print(f"\n{result['file_name']}:")
        print(f"  Total: {result['total_matches']}")
        for sector, count in result['sector_breakdown'].items():
            print(f"    - {sector}: {count}")
    
    # Save results
    save_semantic_results(all_results)
    
    print("\n" + "="*80)
    print("SEMANTIC SEARCH COMPLETE")
    print("="*80)

# In[44]:


from typing import List, Dict, Union
from dataclasses import dataclass, field

@dataclass
class CombinedMatch:
    """Unified match structure after deduplication"""
    chunk_id: str
    text: str
    char_start: int
    char_end: int
    sources: List[str]  # ["keyword_search", "semantic_search"] or just one
    
    # Keyword-specific
    matched_keywords: List[str] = field(default_factory=list)
    
    # Semantic-specific
    similarity_score: float = 0.0
    matched_query: str = ""
    sector: str = ""
    
    # Metadata
    found_by: str = ""  # "keyword_only", "semantic_only", "both"


class CrossStoreDeduplicator:
    """Deduplicate matches across keyword and semantic search stores"""
    
    def __init__(self, overlap_threshold: float = 0.5):
        """
        Args:
            overlap_threshold: Minimum overlap ratio to consider duplicates (0-1)
        """
        self.overlap_threshold = overlap_threshold
    
    def _calculate_overlap(self, start1: int, end1: int, 
                          start2: int, end2: int) -> float:
        """Calculate overlap ratio between two text spans"""
        overlap_start = max(start1, start2)
        overlap_end = min(end1, end2)
        
        if overlap_start >= overlap_end:
            return 0.0  # No overlap
        
        overlap_length = overlap_end - overlap_start
        span1_length = end1 - start1
        
        # Calculate overlap as percentage of first span
        return overlap_length / span1_length if span1_length > 0 else 0.0
    
    def deduplicate(self, keyword_matches: List[KeywordMatch], 
                   semantic_matches: List[SemanticMatch]) -> List[CombinedMatch]:
        """
        Deduplicate keyword and semantic matches
        
        Returns:
            List of CombinedMatch objects with duplicates merged
        """
        print("\n" + "="*80)
        print("CROSS-STORE DEDUPLICATION")
        print("="*80)
        
        print(f"\nInput:")
        print(f"  Keyword matches: {len(keyword_matches)}")
        print(f"  Semantic matches: {len(semantic_matches)}")
        
        # Convert to combined format
        combined_matches = []
        
        # Add all keyword matches first
        for kw_match in keyword_matches:
            combined = CombinedMatch(
                chunk_id=kw_match.chunk_id,
                text=kw_match.text,
                char_start=kw_match.char_start,
                char_end=kw_match.char_end,
                sources=["keyword_search"],
                matched_keywords=kw_match.matched_keywords,
                found_by="keyword_only"
            )
            combined_matches.append(combined)
        
        # Process semantic matches
        matched_semantic = 0
        new_semantic = 0
        
        for sem_match in semantic_matches:
            # Check if this semantic match overlaps with any existing keyword match
            found_overlap = False
            
            for combined in combined_matches:
                if "keyword_search" in combined.sources:
                    overlap = self._calculate_overlap(
                        sem_match.char_start, sem_match.char_end,
                        combined.char_start, combined.char_end
                    )
                    
                    if overlap >= self.overlap_threshold:
                        # Found overlap - merge semantic info into existing match
                        combined.sources.append("semantic_search")
                        combined.similarity_score = sem_match.similarity_score
                        combined.matched_query = sem_match.matched_query
                        combined.sector = sem_match.sector
                        combined.found_by = "both"
                        
                        # Extend text range if semantic match is larger
                        combined.char_start = min(combined.char_start, sem_match.char_start)
                        combined.char_end = max(combined.char_end, sem_match.char_end)
                        
                        # Use longer text
                        if len(sem_match.text) > len(combined.text):
                            combined.text = sem_match.text
                        
                        matched_semantic += 1
                        found_overlap = True
                        break
            
            if not found_overlap:
                # No overlap - add as new semantic-only match
                combined = CombinedMatch(
                    chunk_id=f"combined_{len(combined_matches):04d}",
                    text=sem_match.text,
                    char_start=sem_match.char_start,
                    char_end=sem_match.char_end,
                    sources=["semantic_search"],
                    similarity_score=sem_match.similarity_score,
                    matched_query=sem_match.matched_query,
                    sector=sem_match.sector,
                    found_by="semantic_only"
                )
                combined_matches.append(combined)
                new_semantic += 1
        
        # Sort by position
        combined_matches.sort(key=lambda x: x.char_start)
        
        # Final deduplication pass (in case of any remaining overlaps)
        final_matches = self._final_dedup_pass(combined_matches)
        
        # Statistics
        print(f"\nResults:")
        print(f"  Total unique chunks: {len(final_matches)}")
        
        found_by_keyword = len([m for m in final_matches if m.found_by == "keyword_only"])
        found_by_semantic = len([m for m in final_matches if m.found_by == "semantic_only"])
        found_by_both = len([m for m in final_matches if m.found_by == "both"])
        
        print(f"\nBreakdown:")
        print(f"  Found by keyword only: {found_by_keyword}")
        print(f"  Found by semantic only: {found_by_semantic}")
        print(f"  Found by both: {found_by_both}")
        
        print(f"\nDuplicates removed: {len(keyword_matches) + len(semantic_matches) - len(final_matches)}")
        print(f"Overlap rate: {found_by_both / len(final_matches) * 100:.1f}%")
        
        return final_matches
    
    def _final_dedup_pass(self, matches: List[CombinedMatch]) -> List[CombinedMatch]:
        """Final pass to remove any remaining overlaps"""
        if not matches:
            return []
        
        deduplicated = [matches[0]]
        
        for current in matches[1:]:
            last = deduplicated[-1]
            
            overlap = self._calculate_overlap(
                current.char_start, current.char_end,
                last.char_start, last.char_end
            )
            
            if overlap >= self.overlap_threshold:
                # Merge into last match
                # Combine sources
                for source in current.sources:
                    if source not in last.sources:
                        last.sources.append(source)
                
                # Merge keywords
                last.matched_keywords.extend(current.matched_keywords)
                last.matched_keywords = list(set(last.matched_keywords))
                
                # Keep higher similarity score
                if current.similarity_score > last.similarity_score:
                    last.similarity_score = current.similarity_score
                    last.matched_query = current.matched_query
                    last.sector = current.sector
                
                # Update found_by
                if len(last.sources) > 1:
                    last.found_by = "both"
                
                # Extend range
                last.char_start = min(last.char_start, current.char_start)
                last.char_end = max(last.char_end, current.char_end)
                
                # Use longer text
                if len(current.text) > len(last.text):
                    last.text = current.text
            else:
                # No overlap - add as new
                deduplicated.append(current)
        
        return deduplicated


def save_combined_results(results: List[Dict], output_file: str = "combined_deduplicated_results.json"):
    """Save deduplicated combined results"""
    
    json_results = []
    
    for result in results:
        matches_dicts = []
        for match in result['matches']:
            matches_dicts.append({
                'chunk_id': match.chunk_id,
                'text': match.text,
                'char_start': match.char_start,
                'char_end': match.char_end,
                'sources': match.sources,
                'found_by': match.found_by,
                'matched_keywords': match.matched_keywords,
                'similarity_score': match.similarity_score,
                'matched_query': match.matched_query,
                'sector': match.sector
            })
        
        json_results.append({
            'file_name': result['file_name'],
            'project_id': result['project_id'],
            'total_matches': result['total_matches'],
            'found_by_keyword_only': result['found_by_keyword_only'],
            'found_by_semantic_only': result['found_by_semantic_only'],
            'found_by_both': result['found_by_both'],
            'matches': matches_dicts
        })
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(json_results, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Combined results saved to: {output_file}")


# MAIN EXECUTION
def process_pad_with_deduplication(keyword_results: Dict, semantic_results: Dict) -> Dict:
    """Process a single PAD with cross-store deduplication"""
    
    print(f"\n{'='*80}")
    print(f"Processing: {keyword_results['file_name']}")
    print(f"{'='*80}")
    
    # Initialize deduplicator
    deduplicator = CrossStoreDeduplicator(overlap_threshold=0.5)
    
    # Deduplicate
    combined_matches = deduplicator.deduplicate(
        keyword_results['matches'],
        semantic_results['matches']
    )
    
    # Calculate stats
    found_by_keyword = len([m for m in combined_matches if m.found_by == "keyword_only"])
    found_by_semantic = len([m for m in combined_matches if m.found_by == "semantic_only"])
    found_by_both = len([m for m in combined_matches if m.found_by == "both"])
    
    return {
        'file_name': keyword_results['file_name'],
        'project_id': keyword_results['project_id'],
        'total_matches': len(combined_matches),
        'found_by_keyword_only': found_by_keyword,
        'found_by_semantic_only': found_by_semantic,
        'found_by_both': found_by_both,
        'matches': combined_matches
    }


if __name__ == "__main__":
    
    print("="*80)
    print("COMBINING KEYWORD + SEMANTIC RESULTS")
    print("="*80)
    
    # Load results from JSON files (from your previous runs)
    import json
    
    # Load keyword results
    with open('keyword_search_results.json', 'r') as f:
        keyword_results_list = json.load(f)
    
    # Load semantic results
    with open('semantic_search_results.json', 'r') as f:
        semantic_results_list = json.load(f)
    
    # Convert back to match objects
    def json_to_keyword_matches(json_data):
        matches = []
        for m in json_data['matches']:
            match = KeywordMatch(
                chunk_id=m['chunk_id'],
                text=m['text'],
                matched_keywords=m['matched_keywords'],
                char_start=m['char_start'],
                char_end=m['char_end'],
                source=m['source']
            )
            matches.append(match)
        return {
            'file_name': json_data['file_name'],
            'project_id': json_data['project_id'],
            'matches': matches
        }
    
    def json_to_semantic_matches(json_data):
        matches = []
        for m in json_data['matches']:
            match = SemanticMatch(
                chunk_id=m['chunk_id'],
                text=m['text'],
                similarity_score=m['similarity_score'],
                matched_query=m['matched_query'],
                sector=m['sector'],
                char_start=m['char_start'],
                char_end=m['char_end'],
                source=m['source']
            )
            matches.append(match)
        return {
            'file_name': json_data['file_name'],
            'project_id': json_data['project_id'],
            'matches': matches
        }
    
    # Convert JSON to objects
    keyword_results_all = [json_to_keyword_matches(kw) for kw in keyword_results_list]
    semantic_results_all = [json_to_semantic_matches(sem) for sem in semantic_results_list]
    
    # Process both PADs
    all_combined = []
    
    for i in range(len(keyword_results_all)):
        combined = process_pad_with_deduplication(
            keyword_results_all[i],
            semantic_results_all[i]
        )
        all_combined.append(combined)
    
    # Combined summary
    print("\n" + "="*80)
    print("FINAL SUMMARY ACROSS ALL PADS")
    print("="*80)
    
    total_matches = sum(r['total_matches'] for r in all_combined)
    total_keyword_only = sum(r['found_by_keyword_only'] for r in all_combined)
    total_semantic_only = sum(r['found_by_semantic_only'] for r in all_combined)
    total_both = sum(r['found_by_both'] for r in all_combined)
    
    print(f"\nTotal unique chunks across both PADs: {total_matches}")
    print(f"\nMethod comparison:")
    print(f"  Keyword only: {total_keyword_only} ({total_keyword_only/total_matches*100:.1f}%)")
    print(f"  Semantic only: {total_semantic_only} ({total_semantic_only/total_matches*100:.1f}%)")
    print(f"  Both methods: {total_both} ({total_both/total_matches*100:.1f}%)")
    
    print(f"\n📊 Key Insights:")
    print(f"  - Keyword recall: {(total_keyword_only + total_both) / total_matches * 100:.1f}%")
    print(f"  - Semantic recall: {(total_semantic_only + total_both) / total_matches * 100:.1f}%")
    print(f"  - Complementary value: {total_semantic_only} chunks ONLY found by semantic search")
    
    # Show per-PAD breakdown
    print(f"\n📄 Per-PAD Breakdown:")
    for result in all_combined:
        print(f"\n{result['file_name']}:")
        print(f"  Total: {result['total_matches']}")
        print(f"  Keyword only: {result['found_by_keyword_only']}")
        print(f"  Semantic only: {result['found_by_semantic_only']}")
        print(f"  Both: {result['found_by_both']}")
    
    # Save results
    save_combined_results(all_combined)
    
    print("\n" + "="*80)
    print("DEDUPLICATION COMPLETE")
    print("="*80)


# ### Classification using Bedrock 

# ### Finding False Positives

# In[57]:


import boto3
import json
import time
from typing import List, Dict
from datetime import datetime
import os

class BedrockBatchClassifier:
    """Handle batch classification via AWS Bedrock"""
    
    def __init__(self, 
                 s3_bucket: str,
                 s3_input_prefix: str = "bedrock-batch/input",
                 s3_output_prefix: str = "bedrock-batch/output",
                 region: str = "us-east-1"):
        """
        Initialize Bedrock batch classifier
        
        Args:
            s3_bucket: Your S3 bucket name
            s3_input_prefix: S3 prefix for input files
            s3_output_prefix: S3 prefix for output files
            region: AWS region
        """
        self.s3_bucket = s3_bucket
        self.s3_input_prefix = s3_input_prefix
        self.s3_output_prefix = s3_output_prefix
        self.region = region
        
        # Initialize clients
        self.s3_client = boto3.client('s3', region_name=region)
        self.bedrock_client = boto3.client('bedrock', region_name=region)
        
        # Model ID for Claude Sonnet 4.5 ← UPDATED
        self.model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        
        print(f"✓ Initialized Bedrock client")
        print(f"  Region: {region}")
        print(f"  S3 Bucket: {s3_bucket}")
        print(f"  Model: {self.model_id}")
    
    def create_classification_prompt(self, chunk_text: str, chunk_id: str) -> str:
        """Create classification prompt for a single chunk with 3 few-shot examples"""
        
        prompt = f"""You are an expert in resilient infrastructure evaluation for World Bank projects.
    
    Your task is to determine if the following text excerpt describes a genuine resilient infrastructure intervention according to the official definition.
    
    ---
    RESILIENT INFRASTRUCTURE DEFINITION:
    
    Resilient infrastructure refers to features or actions within infrastructure projects that enhance their ability to withstand and recover from adverse events, ensuring continued service and functionality, particularly to the most vulnerable groups of society. The focus is on infrastructure systems that are robust, redundant, flexible, and adaptive enough to respond effectively to various stresses, including environmental, economic, or social.
    
    Resilient infrastructure investments start by clearly identifying the hazards that threaten the investments, and involve an assessment to select the measures that secure the economic return from the investment. A resilient infrastructure investment does not always require additional resources—it is a way of investing smartly by accounting for the uncertainty of occurrence of extreme events.
    
    KEY ELEMENTS:
    - Robustness: Physical strength or durability to resist impacts from identified risks
    - Redundancy: Backup systems allowing infrastructure to operate even if one part fails
    - Adaptability: Capacity to be modified in response to changing conditions or future risks
    - Flexibility: Ability to change, evolve, and adapt when disruptions occur
    - Rapidity: Capacity to quickly recover from disruptions
    - Integration: Designing infrastructure with consideration for interdependencies and surrounding systems
    - Preventive Maintenance: Routine checks, upgrades, and disaster recovery plans
    
    QUALIFYING ACTIVITIES:
    (i) Improved engineering design that considers exposure to identified hazards
    (ii) Risk-informed asset management covering infrastructure condition monitoring, preventive maintenance, and rapid repair
    (iii) Business continuity planning and contingency programming informed by early-warning systems
    (iv) A systems approach to planning
    (v) Strong stakeholder engagement, coordination and institutional capacity
    
    ---
    EXAMPLES:
    
    EXAMPLE 1 - POSITIVE:
    Text: "The project will upgrade 15 substations to enhance their resilience to flooding and seismic events. This includes: (i) elevating critical equipment above the 100-year flood level; (ii) installing seismic isolation systems for transformers; (iii) deploying mobile substations for rapid response and recovery to climate events."
    
    Classification:
    {{
      "classification": "POSITIVE",
      "confidence": "HIGH",
      "reasoning": "Explicitly describes infrastructure upgrades with specific resilience features (elevation, seismic protection, mobile backups) to address identified hazards.",
      "key_elements_present": ["robustness", "redundancy", "rapidity"],
      "hazards_mentioned": ["flooding", "seismic"],
      "intervention_type": "Engineering Design"
    }}
    
    EXAMPLE 2 - NEGATIVE (Boilerplate/Acronyms):
    Text: "CERC - Contingent Emergency Response Component; DRM - Disaster Risk Management; ESMF - Environmental and Social Management Framework; GDP - Gross Domestic Product"
    
    Classification:
    {{
      "classification": "NEGATIVE",
      "confidence": "HIGH",
      "reasoning": "This is an acronym list with no description of actual resilient infrastructure interventions or measures.",
      "key_elements_present": [],
      "hazards_mentioned": [],
      "intervention_type": "NONE"
    }}
    
    EXAMPLE 3 - NEGATIVE (Problem Description Only):
    Text: "The region faces significant climate risks including recurrent flooding, landslides, and extreme temperature events. These hazards threaten existing infrastructure and pose challenges to service delivery."
    
    Classification:
    {{
      "classification": "NEGATIVE",
      "confidence": "HIGH",
      "reasoning": "Describes climate risks and problems but does not describe any resilient infrastructure solutions, interventions, or measures to address these hazards.",
      "key_elements_present": [],
      "hazards_mentioned": ["flooding", "landslides", "extreme temperature"],
      "intervention_type": "NONE"
    }}
    
    ---
    TEXT EXCERPT TO EVALUATE:
    
    {chunk_text}
    
    ---
    CLASSIFICATION INSTRUCTIONS:
    
    Analyze the text above and respond ONLY with a JSON object in this exact format:
    
    {{
      "chunk_id": "{chunk_id}",
      "classification": "POSITIVE" or "NEGATIVE",
      "confidence": "HIGH" or "MEDIUM" or "LOW",
      "reasoning": "Brief explanation (1-2 sentences) of why this is/isn't resilient infrastructure",
      "intervention_type": "Select ONE: Engineering Design | Asset Management | Contingency Planning | System Planning | Institutional Capacity | Environmental Considerations | Cross-Sectoral Integration | Community Engagement | NONE"
    }}
    
    CRITICAL RULES:
    - Mark POSITIVE only if text explicitly describes infrastructure features/actions that enhance resilience
    - Mark NEGATIVE if it's general infrastructure, problem descriptions, acronym lists, or boilerplate text
    - Respond with ONLY valid JSON, no additional text before or after"""
    
        return prompt
        
    def prepare_batch_input(self, chunks: List[CombinedMatch], 
                           batch_size: int = 5) -> List[str]:
        """
        Prepare batch input files for Bedrock
        
        Args:
            chunks: List of CombinedMatch objects to classify
            batch_size: Number of chunks per batch request
        
        Returns:
            List of S3 keys for uploaded input files
        """
        print(f"\nPreparing batch input...")
        print(f"  Total chunks: {len(chunks)}")
        print(f"  Batch size: {batch_size}")
        
        batches = []
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            batches.append(batch)
        
        print(f"  Number of batches: {len(batches)}")
        
        # Create JSONL file with all requests
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        input_file = f"ri_classification_input_{timestamp}.jsonl"
        
        requests = []
        for batch_idx, batch in enumerate(batches):
            # Create single request with multiple chunks
            combined_text = "\n\n---CHUNK SEPARATOR---\n\n".join([
                f"CHUNK {i+1} (ID: {chunk.chunk_id}):\n{chunk.text}"
                for i, chunk in enumerate(batch)
            ])
            
            prompt = self.create_classification_prompt(combined_text, f"batch_{batch_idx}")
            
            request = {
                "recordId": f"batch_{batch_idx}",
                "modelInput": {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 2000,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                }
            }
            requests.append(request)
        
        # Write to local file
        with open(input_file, 'w') as f:
            for request in requests:
                f.write(json.dumps(request) + '\n')
        
        # Upload to S3
        s3_key = f"{self.s3_input_prefix}/{input_file}"
        self.s3_client.upload_file(input_file, self.s3_bucket, s3_key)
        
        print(f"✓ Uploaded input file to s3://{self.s3_bucket}/{s3_key}")
        
        # Clean up local file
        os.remove(input_file)
        
        return s3_key
    
    def submit_batch_job(self, input_s3_key: str, job_name: str = None) -> str:
        """
        Submit batch inference job to Bedrock
        
        Args:
            input_s3_key: S3 key of input JSONL file
            job_name: Optional custom job name
        
        Returns:
            Job ARN
        """
        if job_name is None:
            # Use HYPHENS not underscores
            job_name = f"ri-classification-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        print(f"\nSubmitting batch job: {job_name}")
        
        response = self.bedrock_client.create_model_invocation_job(
            roleArn=f"arn:aws:iam::{self._get_account_id()}:role/BedrockBatchInferenceRole",
            modelId=self.model_id,
            jobName=job_name,
            inputDataConfig={
                "s3InputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{input_s3_key}"
                }
            },
            outputDataConfig={
                "s3OutputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{self.s3_output_prefix}/"  # MUST END WITH SLASH
                }
            }
        )
        
        job_arn = response['jobArn']
        print(f"✓ Job submitted successfully")
        print(f"  Job ARN: {job_arn}")
        
        return job_arn
    
    def _get_account_id(self) -> str:
        """Get AWS account ID"""
        sts = boto3.client('sts')
        return sts.get_caller_identity()['Account']
    
    def monitor_job(self, job_arn: str, poll_interval: int = 30):
        """
        Monitor batch job until completion
        
        Args:
            job_arn: Job ARN to monitor
            poll_interval: Seconds between status checks
        """
        print(f"\nMonitoring job: {job_arn}")
        print(f"Polling every {poll_interval} seconds...\n")
        
        while True:
            response = self.bedrock_client.get_model_invocation_job(
                jobIdentifier=job_arn
            )
            
            status = response['status']
            
            if status == 'Completed':
                print(f"\n✓ Job completed successfully!")
                print(f"  Output location: {response['outputDataConfig']['s3OutputDataConfig']['s3Uri']}")
                return response
            
            elif status == 'Failed':
                print(f"\n❌ Job failed!")
                print(f"  Message: {response.get('message', 'No error message')}")
                return response
            
            elif status in ['InProgress', 'Submitted']:
                print(f"  Status: {status} - waiting...", end='\r')
                time.sleep(poll_interval)
            
            else:
                print(f"  Unknown status: {status}")
                time.sleep(poll_interval)
    
    def download_results(self, job_arn: str, local_dir: str = "bedrock_results") -> str:
        """
        Download and parse batch results
        
        Args:
            job_arn: Job ARN
            local_dir: Local directory to save results
        
        Returns:
            Path to downloaded results file
        """
        # Get job details
        response = self.bedrock_client.get_model_invocation_job(
            jobIdentifier=job_arn
        )
        
        output_uri = response['outputDataConfig']['s3OutputDataConfig']['s3Uri']
        
        # Parse S3 URI
        # Format: s3://bucket/prefix/job-name/output.jsonl.out
        parts = output_uri.replace("s3://", "").split("/")
        bucket = parts[0]
        prefix = "/".join(parts[1:])
        
        # List objects in output location
        response = self.s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix=prefix
        )
        
        # Find output file
        output_files = [obj['Key'] for obj in response.get('Contents', []) 
                       if obj['Key'].endswith('.out')]
        
        if not output_files:
            print("❌ No output files found")
            return None
        
        output_key = output_files[0]
        
        # Download
        os.makedirs(local_dir, exist_ok=True)
        local_file = os.path.join(local_dir, os.path.basename(output_key))
        
        self.s3_client.download_file(bucket, output_key, local_file)
        
        print(f"✓ Downloaded results to: {local_file}")
        
        return local_file
    
    def parse_results(self, results_file: str) -> List[Dict]:
        """Parse Bedrock batch results"""
        
        classifications = []
        
        with open(results_file, 'r') as f:
            for line in f:
                result = json.loads(line)
                
                if result.get('modelOutput'):
                    content = result['modelOutput']['content'][0]['text']
                    
                    # Parse JSON response
                    try:
                        classification = json.loads(content)
                        classifications.append(classification)
                    except json.JSONDecodeError:
                        print(f"⚠️  Failed to parse response for record: {result.get('recordId')}")
                        continue
        
        print(f"✓ Parsed {len(classifications)} classifications")
        
        return classifications


# MAIN EXECUTION
def run_bedrock_batch_classification(chunks: List[CombinedMatch], 
                                     s3_bucket: str,
                                     batch_size: int = 5):
    """
    Complete workflow for Bedrock batch classification
    
    Args:
        chunks: List of chunks to classify
        s3_bucket: Your S3 bucket name
        batch_size: Chunks per batch request
    """
    
    print("="*80)
    print("BEDROCK BATCH CLASSIFICATION")
    print("="*80)
    
    # Initialize classifier
    classifier = BedrockBatchClassifier(
        s3_bucket=s3_bucket,
        region="us-east-1"  # Change if needed
    )
    
    # Step 1: Prepare input
    input_s3_key = classifier.prepare_batch_input(chunks, batch_size=batch_size)
    
    # Step 2: Submit job
    job_arn = classifier.submit_batch_job(input_s3_key)
    
    # Step 3: Monitor
    classifier.monitor_job(job_arn, poll_interval=30)
    
    # Step 4: Download results
    results_file = classifier.download_results(job_arn)
    
    # Step 5: Parse results
    classifications = classifier.parse_results(results_file)
    
    return classifications


# Update S3 Configuration - remove spaces
S3_BUCKET = "cpf-2025"
S3_INPUT_PREFIX = "Natalias-Batch-Work/bedrock-batch-input"   # Changed spaces to hyphens
S3_OUTPUT_PREFIX = "Natalias-Batch-Work/bedrock-batch-output"  # Changed spaces to hyphens

# Fix job name and output path in submit_batch_job method
def submit_batch_job(self, input_s3_key: str, job_name: str = None) -> str:
    """Submit batch inference job to Bedrock"""
    
    if job_name is None:
        # Use hyphens instead of underscores
        job_name = f"ri-classification-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    print(f"\nSubmitting batch job: {job_name}")
    
    response = self.bedrock_client.create_model_invocation_job(
        roleArn=f"arn:aws:iam::{self._get_account_id()}:role/BedrockBatchInferenceRole",
        modelId=self.model_id,
        jobName=job_name,
        inputDataConfig={
            "s3InputDataConfig": {
                "s3Uri": f"s3://{self.s3_bucket}/{input_s3_key}"
            }
        },
        outputDataConfig={
            "s3OutputDataConfig": {
                "s3Uri": f"s3://{self.s3_bucket}/{self.s3_output_prefix}/"  # Added trailing slash
            }
        }
    )
    
    job_arn = response['jobArn']
    print(f"✓ Job submitted successfully")
    print(f"  Job ARN: {job_arn}")
    
    return job_arn

if __name__ == "__main__":
    
    # Load your combined chunks
    with open('combined_deduplicated_results.json', 'r') as f:
        combined_results = json.load(f)
    
    # Collect all chunks
    all_chunks = []
    for result in combined_results:
        for match_dict in result['matches']:
            # Reconstruct CombinedMatch object
            chunk = CombinedMatch(
                chunk_id=match_dict['chunk_id'],
                text=match_dict['text'],
                char_start=match_dict['char_start'],
                char_end=match_dict['char_end'],
                sources=match_dict['sources'],
                matched_keywords=match_dict['matched_keywords'],
                similarity_score=match_dict['similarity_score'],
                matched_query=match_dict['matched_query'],
                sector=match_dict['sector'],
                found_by=match_dict['found_by']
            )
            all_chunks.append(chunk)
    
    print(f"Total chunks to classify: {len(all_chunks)}")
    
    # Initialize classifier with your bucket
    classifier = BedrockBatchClassifier(
        s3_bucket="cpf-2025",
        s3_input_prefix="bedrock-ri-batch/input",      # No spaces!
        s3_output_prefix="bedrock-ri-batch/output",    # No spaces!
        region="us-east-1"
    )
    
    # Run classification
    print("\n" + "="*80)
    print("STARTING BEDROCK BATCH CLASSIFICATION")
    print("="*80)
    
    # Step 1: Prepare input
    input_s3_key = classifier.prepare_batch_input(all_chunks, batch_size=1)
    
    # Step 2: Submit job
    job_arn = classifier.submit_batch_job(input_s3_key)
    
    # Step 3: Monitor (this will poll every 30 seconds)
    print("\n⏳ Waiting for job to complete...")
    print("This typically takes 5-15 minutes for 343 chunks")
    classifier.monitor_job(job_arn, poll_interval=30)
    
    # Step 4: Download results
    results_file = classifier.download_results(job_arn)
    
    # Step 5: Parse results
    classifications = classifier.parse_results(results_file)
    
    # Step 6: Analyze results
    print("\n" + "="*80)
    print("CLASSIFICATION RESULTS")
    print("="*80)
    
    positive = [c for c in classifications if c['classification'] == 'POSITIVE']
    negative = [c for c in classifications if c['classification'] == 'NEGATIVE']
    
    print(f"\nTotal classified: {len(classifications)}")
    print(f"  POSITIVE (True RI): {len(positive)} ({len(positive)/len(classifications)*100:.1f}%)")
    print(f"  NEGATIVE (False positives): {len(negative)} ({len(negative)/len(classifications)*100:.1f}%)")
    
    # Confidence breakdown
    high_conf = [c for c in positive if c['confidence'] == 'HIGH']
    medium_conf = [c for c in positive if c['confidence'] == 'MEDIUM']
    low_conf = [c for c in positive if c['confidence'] == 'LOW']
    
    print(f"\nPositive matches by confidence:")
    print(f"  HIGH: {len(high_conf)}")
    print(f"  MEDIUM: {len(medium_conf)}")
    print(f"  LOW: {len(low_conf)}")
    
    # Save classifications
    with open('bedrock_classifications.json', 'w') as f:
        json.dump(classifications, f, indent=2)
    
    print(f"\n✓ Saved classifications to: bedrock_classifications.json")
    
    print("\n" + "="*80)
    print("CLASSIFICATION COMPLETE")
    print("="*80)

# In[64]:


import boto3
import json

s3 = boto3.client('s3', region_name='us-east-1')

# Download the actual results file (2.4 MB one)
s3.download_file(
    'cpf-2025',
    'bedrock-ri-batch/output/chn8g998x7ao/ri_classification_input_20251201_203905.jsonl.out',
    'bedrock_results/actual_results.jsonl.out'
)

print("✓ Downloaded actual results file")

# Parse it
classifications = []

with open('bedrock_results/actual_results.jsonl.out', 'r') as f:
    for line in f:
        result = json.loads(line)
        
        if result.get('modelOutput'):
            content = result['modelOutput']['content'][0]['text']
            
            try:
                # Strip markdown code blocks if present
                content = content.replace('```json\n', '').replace('\n```', '').strip()
                classification = json.loads(content)
                classifications.append(classification)
            except json.JSONDecodeError as e:
                print(f"⚠️  Failed to parse response: {e}")
                print(f"Content: {content[:200]}...")

print(f"\n✓ Parsed {len(classifications)} classifications")

# Save to file
with open('bedrock_classifications.json', 'w') as f:
    json.dump(classifications, f, indent=2)

print(f"✓ Saved to: bedrock_classifications.json")

# Quick summary
positive = [c for c in classifications if c.get('classification') == 'POSITIVE']
negative = [c for c in classifications if c.get('classification') == 'NEGATIVE']

print(f"\n📊 Results:")
print(f"  Total: {len(classifications)}")
print(f"  POSITIVE: {len(positive)} ({len(positive)/len(classifications)*100:.1f}%)")
print(f"  NEGATIVE: {len(negative)} ({len(negative)/len(classifications)*100:.1f}%)")

# ### Mapping to extract t

# In[82]:


import json

# Load original chunks in the SAME ORDER they were sent to Bedrock
with open('combined_deduplicated_results.json', 'r') as f:
    combined_results = json.load(f)

# Collect all chunks IN ORDER (same as original script)
all_chunks = []
for result in combined_results:
    for match_dict in result['matches']:
        all_chunks.append(match_dict)

print(f"Total original chunks: {len(all_chunks)}")

# Load classifications
with open('bedrock_classifications.json', 'r') as f:
    classifications = json.load(f)

print(f"Total classifications: {len(classifications)}")

# Create mapping: batch_X → original chunk_id
batch_to_original = {}
for i, chunk in enumerate(all_chunks):
    batch_id = f"batch_{i}"
    batch_to_original[batch_id] = chunk

print(f"Created mapping for {len(batch_to_original)} chunks")

# Enrich classifications with original data
enriched_classifications = []
missing_count = 0

for classification in classifications:
    batch_id = classification['chunk_id']
    
    # Look up original chunk
    original_chunk = batch_to_original.get(batch_id)
    
    if not original_chunk:
        print(f"⚠️  No mapping found for {batch_id}")
        missing_count += 1
        continue
    
    # Merge classification with original data
    enriched = {
        'chunk_id': original_chunk['chunk_id'],  # ← Use ORIGINAL chunk_id
        'batch_id': batch_id,  # Keep batch_id for reference
        'classification': classification['classification'],
        'confidence': classification['confidence'],
        'reasoning': classification['reasoning'],
        'intervention_type': classification.get('intervention_type', 'NONE'),
        'key_elements_present': classification.get('key_elements_present', []),
        'hazards_mentioned': classification.get('hazards_mentioned', []),
        # Add original text and metadata
        'text': original_chunk['text'],
        'char_start': original_chunk['char_start'],
        'char_end': original_chunk['char_end'],
        'sources': original_chunk['sources'],
        'found_by': original_chunk['found_by'],
        'matched_keywords': original_chunk.get('matched_keywords', []),
        'similarity_score': original_chunk.get('similarity_score'),
        'sector': original_chunk.get('sector', '')
    }
    
    enriched_classifications.append(enriched)

print(f"\n✓ Enriched {len(enriched_classifications)} classifications")

if missing_count > 0:
    print(f"⚠️  {missing_count} classifications couldn't be mapped")

# Separate POSITIVE and NEGATIVE
positive_chunks = [c for c in enriched_classifications if c['classification'] == 'POSITIVE']
negative_chunks = [c for c in enriched_classifications if c['classification'] == 'NEGATIVE']

print(f"\n✓ Results:")
print(f"  POSITIVE (True RI): {len(positive_chunks)}")
print(f"  NEGATIVE (False positives): {len(negative_chunks)}")

# Save positive chunks for extraction
with open('positive_chunks_for_extraction.json', 'w') as f:
    json.dump(positive_chunks, f, indent=2)

print(f"\n✓ Saved {len(positive_chunks)} positive chunks (WITH TEXT) to: positive_chunks_for_extraction.json")

# Verification - check first positive chunk
if positive_chunks:
    print("\n" + "="*80)
    print("VERIFICATION: First positive chunk")
    print("="*80)
    first = positive_chunks[0]
    print(f"Original Chunk ID: {first['chunk_id']}")
    print(f"Batch ID: {first['batch_id']}")
    print(f"Classification: {first['classification']}")
    print(f"Intervention Type: {first['intervention_type']}")
    print(f"\nText preview (first 300 chars):")
    print(first['text'][:300] + "..." if len(first['text']) > 300 else first['text'])

# In[90]:


import json

with open('positive_chunks_for_extraction.json', 'r') as f:
    positive = json.load(f)

print(f"Total positive chunks: {len(positive)}")

# Check first 3
for i in range(min(3, len(positive))):
    chunk = positive[i]
    print(f"\n{'='*80}")
    print(f"Chunk #{i+1}")
    print(f"ID: {chunk['chunk_id']}")
    print(f"Classification: {chunk['classification']}")
    print(f"Intervention Type: {chunk['intervention_type']}")
    print(f"Text length: {len(chunk['text'])} chars")
    print(f"Text preview: {chunk['text'][:200]}...")

# In[92]:


import json

# Load all three files
with open('batch_id_mapping.json', 'r') as f:
    batch_to_original = json.load(f)

with open('bedrock_classifications.json', 'r') as f:
    classifications = json.load(f)

with open('combined_deduplicated_results.json', 'r') as f:
    combined_results = json.load(f)

# Build original chunks lookup
chunk_lookup = {}
for result in combined_results:
    for match in result['matches']:
        chunk_lookup[match['chunk_id']] = match

print("="*80)
print("MAPPING VERIFICATION")
print("="*80)

# Check 1: Did we extract mapping for ALL batch_X IDs?
batch_ids_in_classifications = [c['chunk_id'] for c in classifications if c['chunk_id'].startswith('batch_')]
batch_ids_with_mapping = list(batch_to_original.keys())

print(f"\n1. BATCH ID COVERAGE:")
print(f"   Batch IDs in classifications: {len(batch_ids_in_classifications)}")
print(f"   Batch IDs with mapping: {len(batch_ids_with_mapping)}")
print(f"   Missing mappings: {len(set(batch_ids_in_classifications) - set(batch_ids_with_mapping))}")

if set(batch_ids_in_classifications) - set(batch_ids_with_mapping):
    print(f"   ⚠️  Missing: {set(batch_ids_in_classifications) - set(batch_ids_with_mapping)}")

# Check 2: Do ALL mapped IDs exist in original chunks?
print(f"\n2. ORIGINAL CHUNK LOOKUP:")
missing_chunks = []
for batch_id, original_id in batch_to_original.items():
    if original_id not in chunk_lookup:
        missing_chunks.append((batch_id, original_id))

print(f"   Total mapped IDs: {len(batch_to_original)}")
print(f"   Found in original chunks: {len(batch_to_original) - len(missing_chunks)}")
print(f"   NOT found in original chunks: {len(missing_chunks)}")

if missing_chunks:
    print(f"\n   ⚠️  MISSING CHUNKS:")
    for batch_id, orig_id in missing_chunks[:10]:
        print(f"      {batch_id} → {orig_id} (NOT FOUND)")

# Check 3: Are there non-batch IDs that already match?
non_batch_ids = [c['chunk_id'] for c in classifications if not c['chunk_id'].startswith('batch_')]
non_batch_found = [cid for cid in non_batch_ids if cid in chunk_lookup]

print(f"\n3. NON-BATCH IDs (already have original ID):")
print(f"   Non-batch IDs in classifications: {len(non_batch_ids)}")
print(f"   Found in original chunks: {len(non_batch_found)}")
print(f"   NOT found: {len(non_batch_ids) - len(non_batch_found)}")

# Check 4: Total success rate
total_classifications = len(classifications)
successfully_mapped = 0

for classification in classifications:
    cls_id = classification['chunk_id']
    
    if cls_id.startswith('batch_'):
        original_id = batch_to_original.get(cls_id)
        if original_id and original_id in chunk_lookup:
            successfully_mapped += 1
    else:
        if cls_id in chunk_lookup:
            successfully_mapped += 1

print(f"\n4. OVERALL SUCCESS RATE:")
print(f"   Total classifications: {total_classifications}")
print(f"   Successfully mapped to original chunks: {successfully_mapped}")
print(f"   Success rate: {successfully_mapped/total_classifications*100:.1f}%")
print(f"   Failed: {total_classifications - successfully_mapped}")

# Check 5: Verify text is present
print(f"\n5. TEXT PRESENCE CHECK:")
with open('positive_chunks_for_extraction.json', 'r') as f:
    positive_chunks = json.load(f)

chunks_with_text = [c for c in positive_chunks if c.get('text') and len(c['text']) > 0]
chunks_without_text = [c for c in positive_chunks if not c.get('text') or len(c['text']) == 0]

print(f"   Positive chunks: {len(positive_chunks)}")
print(f"   With text: {len(chunks_with_text)}")
print(f"   Without text: {len(chunks_without_text)}")

if chunks_without_text:
    print(f"\n   ⚠️  CHUNKS WITHOUT TEXT:")
    for chunk in chunks_without_text[:5]:
        print(f"      {chunk['chunk_id']}")

# Check 6: Sample verification - check if text makes sense
print(f"\n6. SAMPLE TEXT VERIFICATION:")
print(f"   Checking if classified content matches extracted text...")

# Take 5 random positive chunks and verify
import random
sample_size = min(5, len(positive_chunks))
samples = random.sample(positive_chunks, sample_size)

for i, chunk in enumerate(samples, 1):
    reasoning = chunk.get('reasoning', '')
    text = chunk.get('text', '')[:200]
    
    print(f"\n   Sample {i}:")
    print(f"   ID: {chunk['chunk_id']}")
    print(f"   Reasoning mentions: {reasoning[:100]}...")
    print(f"   Text contains: {text[:100]}...")
    
    # Basic check: does reasoning seem related to text?
    # (This is just a sanity check, not foolproof)

print("\n" + "="*80)
print("VERIFICATION COMPLETE")
print("="*80)

# In[ ]:




# In[94]:


import boto3
import json
import time
from datetime import datetime
from typing import List, Dict

class RIExcerptExtractor:
    """Extract clean RI excerpts from positive chunks"""
    
    def __init__(self, s3_bucket: str, region: str = "us-east-1"):
        self.s3_bucket = s3_bucket
        self.region = region
        self.s3_input_prefix = "bedrock-ri-batch/extraction-input"
        self.s3_output_prefix = "bedrock-ri-batch/extraction-output"
        
        self.s3_client = boto3.client('s3', region_name=region)
        self.bedrock_client = boto3.client('bedrock', region_name=region)
        
        self.model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        
        print(f"✓ Initialized RI Excerpt Extractor")
        print(f"  Model: {self.model_id}")
    
    def create_extraction_prompt(self, chunk_text: str, chunk_id: str, 
                                intervention_type: str, hazards: List[str]) -> str:
        """Create prompt to extract clean RI excerpt"""
        
        hazards_str = ", ".join(hazards) if hazards else "not specified"
        
        prompt = f"""You are an expert in resilient infrastructure evaluation for World Bank projects.

You have been given a text chunk that has been classified as containing resilient infrastructure content. Your task is to extract ONLY the specific sentence(s) or phrase(s) that describe the actual resilient infrastructure intervention, feature, or measure. Dont paraphrase, give the exact relevant part.

---
CONTEXT FROM CLASSIFICATION:

Intervention Type: {intervention_type}
Hazards Mentioned: {hazards_str}

---
FULL TEXT CHUNK:

{chunk_text}

---
EXTRACTION INSTRUCTIONS:

Extract ONLY the sentence(s) or phrase(s) that explicitly describe:
- Infrastructure features that enhance resilience
- Engineering design measures for hazard protection
- Asset management approaches with climate/disaster considerations
- Contingency planning or emergency response systems
- Risk assessments informing infrastructure decisions
- Institutional capacity for resilient infrastructure

DO NOT INCLUDE:
- Background context or problem descriptions
- Project implementation details unrelated to resilience
- Financial or procurement information
- General project descriptions

If multiple sentences describe RI interventions, extract all of them but keep them concise.

---
OUTPUT FORMAT:

Respond ONLY with a JSON object:

{{
  "chunk_id": "{chunk_id}",
  "extracted_excerpt": "The specific sentence(s) describing the RI intervention - be concise but complete",
  "extraction_confidence": "HIGH" or "MEDIUM" or "LOW",
  "notes": "Brief note if any important context was removed or if extraction was challenging"
}}

Respond with ONLY valid JSON, no additional text."""

        return prompt
    
    def prepare_extraction_input(self, positive_chunks: List[Dict]) -> str:
        """Prepare batch input for extraction with padding to meet minimum"""
        
        print(f"\nPreparing extraction batch input...")
        print(f"  Total positive chunks: {len(positive_chunks)}")
        
        # AWS Bedrock requires minimum 100 records for batch jobs
        MIN_BATCH_SIZE = 100
        
        chunks_to_process = positive_chunks.copy()
        
        if len(chunks_to_process) < MIN_BATCH_SIZE:
            shortage = MIN_BATCH_SIZE - len(chunks_to_process)
            print(f"  ⚠️  Need minimum {MIN_BATCH_SIZE} records, padding with {shortage} duplicates...")
            
            # Duplicate chunks to reach minimum (use modulo to cycle through)
            padding_chunks = []
            for i in range(shortage):
                duplicate = chunks_to_process[i % len(chunks_to_process)].copy()
                # Mark as duplicate with unique ID
                duplicate['chunk_id'] = f"{duplicate['chunk_id']}_DUPLICATE_{i+1}"
                padding_chunks.append(duplicate)
            
            chunks_to_process.extend(padding_chunks)
            print(f"  ✓ Padded to {len(chunks_to_process)} records")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        input_file = f"ri_extraction_input_{timestamp}.jsonl"
        
        requests = []
        for chunk in chunks_to_process:
            chunk_id = chunk.get('chunk_id', 'unknown')
            chunk_text = chunk.get('text', chunk.get('full_text', ''))
            intervention_type = chunk.get('intervention_type', 'NONE')
            hazards = chunk.get('hazards_mentioned', [])
            
            prompt = self.create_extraction_prompt(
                chunk_text, 
                chunk_id, 
                intervention_type, 
                hazards
            )
            
            request = {
                "recordId": chunk_id,
                "modelInput": {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 800,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                }
            }
            requests.append(request)
        
        # Write to local file
        with open(input_file, 'w') as f:
            for request in requests:
                f.write(json.dumps(request) + '\n')
        
        # Upload to S3
        s3_key = f"{self.s3_input_prefix}/{input_file}"
        self.s3_client.upload_file(input_file, self.s3_bucket, s3_key)
        
        print(f"✓ Uploaded to s3://{self.s3_bucket}/{s3_key}")
        print(f"  Total requests: {len(requests)}")
        
        import os
        os.remove(input_file)
        
        return s3_key
    
    def submit_extraction_job(self, input_s3_key: str) -> str:
        """Submit extraction batch job"""
        
        job_name = f"ri-extraction-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        print(f"\nSubmitting extraction job: {job_name}")
        
        account_id = boto3.client('sts').get_caller_identity()['Account']
        
        response = self.bedrock_client.create_model_invocation_job(
            roleArn=f"arn:aws:iam::{account_id}:role/BedrockBatchInferenceRole",
            modelId=self.model_id,
            jobName=job_name,
            inputDataConfig={
                "s3InputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{input_s3_key}"
                }
            },
            outputDataConfig={
                "s3OutputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{self.s3_output_prefix}/"
                }
            }
        )
        
        job_arn = response['jobArn']
        print(f"✓ Job submitted: {job_arn}")
        
        return job_arn
    
    def monitor_job(self, job_arn: str, poll_interval: int = 30):
        """Monitor extraction job"""
        
        print(f"\nMonitoring extraction job...")
        print(f"Polling every {poll_interval} seconds...\n")
        
        while True:
            response = self.bedrock_client.get_model_invocation_job(
                jobIdentifier=job_arn
            )
            
            status = response['status']
            
            if status == 'Completed':
                print(f"\n✓ Extraction job completed!")
                return response
            elif status == 'Failed':
                print(f"\n❌ Job failed: {response.get('message', 'Unknown error')}")
                return response
            elif status in ['InProgress', 'Submitted', 'Validating', 'Scheduled']:
                print(f"  Status: {status} - waiting...", end='\r')
                time.sleep(poll_interval)
            else:
                print(f"  Unknown status: {status}")
                time.sleep(poll_interval)
    
    def download_results(self, job_arn: str) -> str:
        """Download extraction results"""
        
        response = self.bedrock_client.get_model_invocation_job(
            jobIdentifier=job_arn
        )
        
        output_uri = response['outputDataConfig']['s3OutputDataConfig']['s3Uri']
        parts = output_uri.replace("s3://", "").split("/")
        bucket = parts[0]
        prefix = "/".join(parts[1:])
        
        # List objects (skip manifest)
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        output_files = [
            obj['Key'] for obj in response.get('Contents', []) 
            if obj['Key'].endswith('.out') and 'manifest' not in obj['Key'].lower()
        ]
        
        if not output_files:
            print("❌ No output files found")
            return None
        
        output_key = output_files[0]
        
        # Download
        import os
        os.makedirs('extraction_results', exist_ok=True)
        local_file = f"extraction_results/{os.path.basename(output_key)}"
        
        self.s3_client.download_file(bucket, output_key, local_file)
        print(f"✓ Downloaded to: {local_file}")
        
        return local_file
    
    def parse_extraction_results(self, results_file: str, 
                                 original_classifications: List[Dict]) -> List[Dict]:
        """Parse extraction results and merge with original data"""
        
        extractions = []
        
        with open(results_file, 'r') as f:
            for line in f:
                result = json.loads(line)
                
                if result.get('modelOutput'):
                    content = result['modelOutput']['content'][0]['text']
                    
                    try:
                        # Strip markdown if present
                        content = content.replace('```json\n', '').replace('\n```', '').strip()
                        extraction = json.loads(content)
                        extractions.append(extraction)
                    except json.JSONDecodeError:
                        print(f"⚠️  Failed to parse extraction for: {result.get('recordId')}")
        
        print(f"✓ Parsed {len(extractions)} extractions")
        
        # Remove duplicates (anything with _DUPLICATE_ in chunk_id)
        original_extractions = [e for e in extractions if '_DUPLICATE_' not in e['chunk_id']]
        duplicate_count = len(extractions) - len(original_extractions)
        
        if duplicate_count > 0:
            print(f"✓ Removed {duplicate_count} duplicate padding records")
        
        print(f"✓ Final count: {len(original_extractions)} unique extractions")
        
        # Merge with original classification data
        chunk_map = {c['chunk_id']: c for c in original_classifications}
        
        enriched_results = []
        for extraction in original_extractions:
            chunk_id = extraction['chunk_id']
            original = chunk_map.get(chunk_id, {})
            
            enriched = {
                'chunk_id': chunk_id,
                'original_text': original.get('text', ''),
                'extracted_excerpt': extraction['extracted_excerpt'],
                'extraction_confidence': extraction.get('extraction_confidence', 'UNKNOWN'),
                'classification_confidence': original.get('confidence', 'UNKNOWN'),
                'intervention_type': original.get('intervention_type', 'NONE'),
                'hazards_mentioned': original.get('hazards_mentioned', []),
                'key_elements': original.get('key_elements_present', []),
                'notes': extraction.get('notes', '')
            }
            
            enriched_results.append(enriched)
        
        return enriched_results


def run_extraction_pipeline(positive_chunks_file: str = 'positive_chunks_for_extraction.json',
                           s3_bucket: str = 'cpf-2025'):
    """Run complete extraction pipeline"""
    
    print("="*80)
    print("RI EXCERPT EXTRACTION PIPELINE")
    print("="*80)
    
    # Load positive chunks
    with open(positive_chunks_file, 'r') as f:
        positive_chunks = json.load(f)
    
    print(f"\nLoaded {len(positive_chunks)} positive chunks for extraction")
    
    # Initialize extractor
    extractor = RIExcerptExtractor(s3_bucket=s3_bucket)
    
    # Prepare input (with padding if needed)
    input_s3_key = extractor.prepare_extraction_input(positive_chunks)
    
    # Submit job
    job_arn = extractor.submit_extraction_job(input_s3_key)
    
    # Monitor
    print(f"\n⏳ Processing extraction requests...")
    extractor.monitor_job(job_arn)
    
    # Download results
    results_file = extractor.download_results(job_arn)
    
    # Parse and enrich (duplicates will be removed here)
    enriched_results = extractor.parse_extraction_results(results_file, positive_chunks)
    
    # Save
    with open('extracted_ri_excerpts.json', 'w') as f:
        json.dump(enriched_results, f, indent=2)
    
    print(f"\n✓ Saved {len(enriched_results)} extracted excerpts to: extracted_ri_excerpts.json")
    
    # Summary
    print("\n" + "="*80)
    print("EXTRACTION SUMMARY")
    print("="*80)
    
    high_conf = len([e for e in enriched_results if e['extraction_confidence'] == 'HIGH'])
    medium_conf = len([e for e in enriched_results if e['extraction_confidence'] == 'MEDIUM'])
    low_conf = len([e for e in enriched_results if e['extraction_confidence'] == 'LOW'])
    
    print(f"\nExtraction confidence:")
    print(f"  HIGH: {high_conf}")
    print(f"  MEDIUM: {medium_conf}")
    print(f"  LOW: {low_conf}")
    
    return enriched_results


if __name__ == "__main__":
    extracted_excerpts = run_extraction_pipeline(
        positive_chunks_file='positive_chunks_for_extraction.json',
        s3_bucket='cpf-2025'
    )


# In[104]:


import json

# Load the corrected excerpts
with open('extracted_ri_excerpts.json', 'r') as f:
    excerpts = json.load(f)

print("="*80)
print("INSPECTING CORRECTED EXTRACTED EXCERPTS")
print("="*80)

# Show HIGH confidence samples
high_conf = [e for e in excerpts if e['extraction_confidence'] == 'HIGH']

print(f"\n✅ HIGH CONFIDENCE SAMPLES ({len(high_conf)} total):\n")

for i, excerpt in enumerate(high_conf[:5], 1):
    print(f"{'='*80}")
    print(f"HIGH CONFIDENCE SAMPLE #{i}")
    print(f"{'='*80}")
    print(f"Chunk ID: {excerpt['chunk_id']}")
    print(f"Intervention Type: {excerpt['intervention_type']}")
    print(f"Hazards: {', '.join(excerpt.get('hazards_mentioned', [])) or 'None specified'}")
    
    print(f"\n--- EXTRACTED EXCERPT ---")
    print(excerpt['extracted_excerpt'][:500] if len(excerpt['extracted_excerpt']) > 500 else excerpt['extracted_excerpt'])
    
    print(f"\n--- NOTES ---")
    print(excerpt.get('notes', 'None'))
    print()

# Show the 3 empty ones
empty = [e for e in excerpts if not e.get('extracted_excerpt') or len(e['extracted_excerpt'].strip()) == 0]

if empty:
    print(f"\n⚠️  EMPTY EXCERPTS ({len(empty)} total):\n")
    for e in empty:
        print(f"  - {e['chunk_id']}: {e.get('notes', 'No notes')}")

print("\n" + "="*80)
print("SUMMARY BY INTERVENTION TYPE")
print("="*80)

intervention_counts = {}
for e in excerpts:
    int_type = e.get('intervention_type', 'NONE')
    intervention_counts[int_type] = intervention_counts.get(int_type, 0) + 1

for int_type, count in sorted(intervention_counts.items(), key=lambda x: x[1], reverse=True):
    print(f"  {int_type}: {count}")

# ### Activities Classification

# In[106]:


import boto3
import json
import time
from datetime import datetime
from typing import List, Dict

class ActivityClassifier:
    """Classify RI excerpts into 8 activity types"""
    
    def __init__(self, s3_bucket: str, region: str = "us-east-1"):
        self.s3_bucket = s3_bucket
        self.region = region
        self.s3_input_prefix = "bedrock-ri-batch/activity-input"
        self.s3_output_prefix = "bedrock-ri-batch/activity-output"
        
        self.s3_client = boto3.client('s3', region_name=region)
        self.bedrock_client = boto3.client('bedrock', region_name=region)
        
        self.model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
        
        print(f"✓ Initialized Activity Classifier")
    
    def create_activity_classification_prompt(self, excerpt: str, chunk_id: str) -> str:
        """Create prompt for activity classification"""
        
        prompt = f"""You are an expert in resilient infrastructure evaluation for World Bank projects.

Your task is to classify the following resilient infrastructure excerpt into ONE of the 8 activity categories.

---
ACTIVITY CATEGORIES:

1. **Institutional Capacity**: Ability of institutions to manage and govern infrastructure systems, including policy formulation, regulation enforcement, resource mobilization, and stakeholder coordination.

2. **System Planning**: Strategic planning of infrastructure considering urban growth, demographics, economic development, and climate change impacts to ensure resilience and sustainability.

3. **Engineering Design**: Technical design incorporating resilience features to withstand hazards using durable materials, innovative construction, and climate considerations.

4. **Asset Management**: Regular maintenance and operation throughout lifecycle, including condition monitoring, preventive maintenance, and rapid repair.

5. **Contingency Planning and Business Continuity**: Emergency response plans, backup systems, and alternative service delivery to ensure infrastructure continues operating during/after disruptions.

6. **Environmental and Ecosystem Considerations**: Integrating environmental and ecosystem-based approaches for natural solutions that enhance resilience and support biodiversity.

7. **Cross-Sectoral Integration**: Addressing interdependencies between infrastructure systems to ensure resilience in one sector enhances others.

8. **Community Engagement and Public Awareness**: Engaging communities in planning, operation, and maintenance to ensure projects are socially inclusive and meet user needs.

---
RI EXCERPT TO CLASSIFY:

{excerpt}

---
CLASSIFICATION INSTRUCTIONS:

Analyze the excerpt and determine which ONE activity category best describes it. Consider:
- What is the PRIMARY focus of this intervention?
- Which activity type does this most closely align with?
- If it spans multiple categories, choose the most dominant one

Respond ONLY with a JSON object:

{{
  "chunk_id": "{chunk_id}",
  "activity_type": "Select ONE: Institutional Capacity | System Planning | Engineering Design | Asset Management | Contingency Planning | Environmental Considerations | Cross-Sectoral Integration | Community Engagement",
  "confidence": "HIGH" or "MEDIUM" or "LOW",
  "reasoning": "Brief explanation (1 sentence) of why this activity type was chosen"
}}

Respond with ONLY valid JSON, no additional text."""

        return prompt
    
    def prepare_activity_input(self, extracted_excerpts: List[Dict]) -> str:
        """Prepare batch input for activity classification with padding"""
        
        print(f"\nPreparing activity classification input...")
        print(f"  Total excerpts: {len(extracted_excerpts)}")
        
        # AWS Bedrock requires minimum 100 records for batch jobs
        MIN_BATCH_SIZE = 100
        
        excerpts_to_process = extracted_excerpts.copy()
        
        if len(excerpts_to_process) < MIN_BATCH_SIZE:
            shortage = MIN_BATCH_SIZE - len(excerpts_to_process)
            print(f"  ⚠️  Need minimum {MIN_BATCH_SIZE} records, padding with {shortage} duplicates...")
            
            # Duplicate excerpts to reach minimum
            padding_excerpts = []
            for i in range(shortage):
                duplicate = excerpts_to_process[i % len(excerpts_to_process)].copy()
                # Mark as duplicate with unique ID
                duplicate['chunk_id'] = f"{duplicate['chunk_id']}_ACTIVITY_DUP_{i+1}"
                padding_excerpts.append(duplicate)
            
            excerpts_to_process.extend(padding_excerpts)
            print(f"  ✓ Padded to {len(excerpts_to_process)} records")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        input_file = f"ri_activity_input_{timestamp}.jsonl"
        
        requests = []
        for excerpt_data in excerpts_to_process:
            chunk_id = excerpt_data['chunk_id']
            excerpt = excerpt_data['extracted_excerpt']
            
            prompt = self.create_activity_classification_prompt(excerpt, chunk_id)
            
            request = {
                "recordId": chunk_id,
                "modelInput": {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 500,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                }
            }
            requests.append(request)
        
        # Write and upload
        with open(input_file, 'w') as f:
            for request in requests:
                f.write(json.dumps(request) + '\n')
        
        s3_key = f"{self.s3_input_prefix}/{input_file}"
        self.s3_client.upload_file(input_file, self.s3_bucket, s3_key)
        
        print(f"✓ Uploaded to s3://{self.s3_bucket}/{s3_key}")
        print(f"  Total requests: {len(requests)}")
        
        import os
        os.remove(input_file)
        
        return s3_key
    
    def submit_activity_job(self, input_s3_key: str) -> str:
        """Submit activity classification job"""
        
        job_name = f"ri-activity-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        
        print(f"\nSubmitting activity classification job: {job_name}")
        
        account_id = boto3.client('sts').get_caller_identity()['Account']
        
        response = self.bedrock_client.create_model_invocation_job(
            roleArn=f"arn:aws:iam::{account_id}:role/BedrockBatchInferenceRole",
            modelId=self.model_id,
            jobName=job_name,
            inputDataConfig={
                "s3InputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{input_s3_key}"
                }
            },
            outputDataConfig={
                "s3OutputDataConfig": {
                    "s3Uri": f"s3://{self.s3_bucket}/{self.s3_output_prefix}/"
                }
            }
        )
        
        job_arn = response['jobArn']
        print(f"✓ Job submitted: {job_arn}")
        
        return job_arn
    
    def monitor_job(self, job_arn: str, poll_interval: int = 30):
        """Monitor activity classification job"""
        
        print(f"\nMonitoring activity classification job...")
        print(f"Polling every {poll_interval} seconds...\n")
        
        while True:
            response = self.bedrock_client.get_model_invocation_job(
                jobIdentifier=job_arn
            )
            
            status = response['status']
            
            if status == 'Completed':
                print(f"\n✓ Activity classification completed!")
                return response
            elif status == 'Failed':
                print(f"\n❌ Job failed: {response.get('message', 'Unknown error')}")
                return response
            elif status in ['InProgress', 'Submitted', 'Validating', 'Scheduled']:
                print(f"  Status: {status} - waiting...", end='\r')
                time.sleep(poll_interval)
            else:
                print(f"  Unknown status: {status}")
                time.sleep(poll_interval)
    
    def download_and_parse_results(self, job_arn: str, 
                                   original_excerpts: List[Dict]) -> List[Dict]:
        """Download and parse activity classification results"""
        
        # Download
        response = self.bedrock_client.get_model_invocation_job(
            jobIdentifier=job_arn
        )
        
        output_uri = response['outputDataConfig']['s3OutputDataConfig']['s3Uri']
        parts = output_uri.replace("s3://", "").split("/")
        bucket = parts[0]
        prefix = "/".join(parts[1:])
        
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        output_files = [
            obj['Key'] for obj in response.get('Contents', []) 
            if obj['Key'].endswith('.out') and 'manifest' not in obj['Key'].lower()
        ]
        
        output_key = output_files[0]
        
        import os
        os.makedirs('activity_results', exist_ok=True)
        local_file = f"activity_results/{os.path.basename(output_key)}"
        
        self.s3_client.download_file(bucket, output_key, local_file)
        print(f"✓ Downloaded to: {local_file}")
        
        # Parse results
        activities = []
        
        with open(local_file, 'r') as f:
            for line in f:
                result = json.loads(line)
                
                if result.get('modelOutput'):
                    content = result['modelOutput']['content'][0]['text']
                    
                    try:
                        # Strip markdown if present
                        content = content.replace('```json\n', '').replace('\n```', '').strip()
                        activity = json.loads(content)
                        activities.append(activity)
                    except json.JSONDecodeError:
                        print(f"⚠️  Failed to parse: {result.get('recordId')}")
        
        print(f"✓ Parsed {len(activities)} activity classifications")
        
        # Remove duplicates (anything with _ACTIVITY_DUP_ in chunk_id)
        original_activities = [a for a in activities if '_ACTIVITY_DUP_' not in a['chunk_id']]
        duplicate_count = len(activities) - len(original_activities)
        
        if duplicate_count > 0:
            print(f"✓ Removed {duplicate_count} duplicate padding records")
        
        print(f"✓ Final count: {len(original_activities)} unique activity classifications")
        
        # Merge with excerpts
        excerpt_map = {e['chunk_id']: e for e in original_excerpts}
        
        final_results = []
        for activity in original_activities:
            chunk_id = activity['chunk_id']
            excerpt_data = excerpt_map.get(chunk_id, {})
            
            final = {
                'chunk_id': chunk_id,
                'extracted_excerpt': excerpt_data.get('extracted_excerpt', ''),
                'activity_type': activity['activity_type'],
                'activity_confidence': activity.get('confidence', 'UNKNOWN'),
                'activity_reasoning': activity.get('reasoning', ''),
                'hazards_mentioned': excerpt_data.get('hazards_mentioned', []),
                'key_elements': excerpt_data.get('key_elements', []),
                'original_text': excerpt_data.get('original_text', '')
            }
            
            final_results.append(final)
        
        return final_results


def run_activity_classification_pipeline(excerpts_file: str = 'extracted_ri_excerpts.json',
                                        s3_bucket: str = 'cpf-2025'):
    """Run complete activity classification pipeline"""
    
    print("="*80)
    print("ACTIVITY CLASSIFICATION PIPELINE")
    print("="*80)
    
    # Load excerpts
    with open(excerpts_file, 'r') as f:
        excerpts = json.load(f)
    
    print(f"\nLoaded {len(excerpts)} extracted excerpts for activity classification")
    
    # Initialize classifier
    classifier = ActivityClassifier(s3_bucket=s3_bucket)
    
    # Prepare input (with padding if needed)
    input_s3_key = classifier.prepare_activity_input(excerpts)
    
    # Submit job
    job_arn = classifier.submit_activity_job(input_s3_key)
    
    # Monitor
    print(f"\n⏳ Processing activity classifications...")
    classifier.monitor_job(job_arn)
    
    # Download and parse (duplicates removed here)
    final_results = classifier.download_and_parse_results(job_arn, excerpts)
    
    # Save
    with open('final_ri_classifications.json', 'w') as f:
        json.dump(final_results, f, indent=2)
    
    print(f"\n✓ Saved {len(final_results)} final classifications to: final_ri_classifications.json")
    
    # Summary
    print("\n" + "="*80)
    print("ACTIVITY CLASSIFICATION SUMMARY")
    print("="*80)
    
    activity_counts = {}
    for result in final_results:
        activity = result['activity_type']
        activity_counts[activity] = activity_counts.get(activity, 0) + 1
    
    print(f"\nBreakdown by activity type:")
    for activity, count in sorted(activity_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {activity}: {count}")
    
    return final_results


def deduplicate_final_results(final_results: List[Dict], 
                              similarity_threshold: float = 0.85) -> List[Dict]:
    """
    Deduplicate final results based on extracted excerpt similarity
    
    Args:
        final_results: List of final classification dictionaries
        similarity_threshold: Similarity threshold for considering duplicates (0-1)
    
    Returns:
        Deduplicated list of results
    """
    from difflib import SequenceMatcher
    
    print("\n" + "="*80)
    print("DEDUPLICATION")
    print("="*80)
    
    print(f"\nInput: {len(final_results)} classifications")
    
    # Remove empty excerpts first
    non_empty = [r for r in final_results if r.get('extracted_excerpt') and len(r['extracted_excerpt'].strip()) > 0]
    empty_count = len(final_results) - len(non_empty)
    
    if empty_count > 0:
        print(f"Removed {empty_count} empty excerpts")
    
    if not non_empty:
        print("⚠️  No non-empty excerpts to deduplicate")
        return []
    
    # Sort by excerpt length (keep longer, more detailed versions)
    non_empty.sort(key=lambda x: len(x['extracted_excerpt']), reverse=True)
    
    # Deduplicate based on text similarity
    unique_results = []
    duplicates = []
    
    for result in non_empty:
        excerpt = result['extracted_excerpt'].strip().lower()
        
        # Check if similar to any existing unique result
        is_duplicate = False
        for unique in unique_results:
            unique_excerpt = unique['extracted_excerpt'].strip().lower()
            
            # Calculate similarity
            similarity = SequenceMatcher(None, excerpt, unique_excerpt).ratio()
            
            if similarity >= similarity_threshold:
                is_duplicate = True
                duplicates.append({
                    'duplicate_id': result['chunk_id'],
                    'kept_id': unique['chunk_id'],
                    'similarity': similarity,
                    'duplicate_text': result['extracted_excerpt'][:100] + "...",
                    'kept_text': unique['extracted_excerpt'][:100] + "..."
                })
                break
        
        if not is_duplicate:
            unique_results.append(result)
    
    print(f"\nDeduplication results:")
    print(f"  Unique excerpts: {len(unique_results)}")
    print(f"  Duplicates removed: {len(duplicates)}")
    print(f"  Similarity threshold: {similarity_threshold}")
    
    if duplicates:
        print(f"\n  Top 5 duplicates found:")
        for i, dup in enumerate(duplicates[:5], 1):
            print(f"\n  {i}. Similarity: {dup['similarity']:.2%}")
            print(f"     Removed: {dup['duplicate_id']}")
            print(f"     Kept: {dup['kept_id']}")
            print(f"     Removed text: {dup['duplicate_text']}")
            print(f"     Kept text: {dup['kept_text']}")
    
    return unique_results


def run_activity_classification_pipeline_with_dedup(excerpts_file: str = 'extracted_ri_excerpts.json',
                                                    s3_bucket: str = 'cpf-2025',
                                                    deduplicate: bool = True,
                                                    similarity_threshold: float = 0.85):
    """Run complete activity classification pipeline with optional deduplication"""
    
    print("="*80)
    print("ACTIVITY CLASSIFICATION PIPELINE (WITH DEDUPLICATION)")
    print("="*80)
    
    # Load excerpts
    with open(excerpts_file, 'r') as f:
        excerpts = json.load(f)
    
    print(f"\nLoaded {len(excerpts)} extracted excerpts for activity classification")
    
    # Initialize classifier
    classifier = ActivityClassifier(s3_bucket=s3_bucket)
    
    # Prepare input (with padding if needed)
    input_s3_key = classifier.prepare_activity_input(excerpts)
    
    # Submit job
    job_arn = classifier.submit_activity_job(input_s3_key)
    
    # Monitor
    print(f"\n⏳ Processing activity classifications...")
    classifier.monitor_job(job_arn)
    
    # Download and parse (duplicates removed here)
    final_results = classifier.download_and_parse_results(job_arn, excerpts)
    
    # DEDUPLICATION STEP
    if deduplicate:
        deduplicated_results = deduplicate_final_results(final_results, similarity_threshold)
        
        # Save both versions
        with open('final_ri_classifications_with_duplicates.json', 'w') as f:
            json.dump(final_results, f, indent=2)
        print(f"\n✓ Saved version WITH duplicates to: final_ri_classifications_with_duplicates.json")
        
        with open('final_ri_classifications.json', 'w') as f:
            json.dump(deduplicated_results, f, indent=2)
        print(f"✓ Saved deduplicated version to: final_ri_classifications.json")
        
        results_to_summarize = deduplicated_results
    else:
        with open('final_ri_classifications.json', 'w') as f:
            json.dump(final_results, f, indent=2)
        print(f"\n✓ Saved {len(final_results)} final classifications to: final_ri_classifications.json")
        results_to_summarize = final_results
    
    # Summary
    print("\n" + "="*80)
    print("FINAL ACTIVITY CLASSIFICATION SUMMARY")
    print("="*80)
    
    activity_counts = {}
    for result in results_to_summarize:
        activity = result['activity_type']
        activity_counts[activity] = activity_counts.get(activity, 0) + 1
    
    print(f"\nBreakdown by activity type ({len(results_to_summarize)} unique interventions):")
    for activity, count in sorted(activity_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {activity}: {count}")
    
    # Hazard summary
    all_hazards = []
    for result in results_to_summarize:
        all_hazards.extend(result.get('hazards_mentioned', []))
    
    if all_hazards:
        from collections import Counter
        hazard_counts = Counter(all_hazards)
        print(f"\nTop hazards mentioned:")
        for hazard, count in hazard_counts.most_common(10):
            print(f"  {hazard}: {count}")
    
    return results_to_summarize


if __name__ == "__main__":
    final_classifications = run_activity_classification_pipeline_with_dedup(
        excerpts_file='extracted_ri_excerpts.json',
        s3_bucket='cpf-2025',
        deduplicate=True,
        similarity_threshold=0.90  # Adjust if needed (0.85 = 85% similar)
    )

# In[ ]:


/Users/munibqasimzia/ri_summary_with_documents.csv
